

int printi(int num);
int prints(char * c);
int readi(int *eP);

int callprint(int i)
{
    int t=100;
    return 0;
}
int main()
{
    prints("Lets do activty selection problem\n");
    int s[6],f[6],i;
    for(i=0;i<6;i++)
    {
        s[i]=i+i*i;
        f[i]=2*i+i*i*i;
    }
    prints("The start time of activities are as follows:\n");
    prints("0 2 6 12 20 30\n");
    for(i=0;i<6;i++)
    {
      callprint(f[i]);
      prints("");
    }
    prints("The finish time of activities are as follows:\n");
    prints("2 3 12 33 72 135\n");
    for(i=0;i<6;i++)
    {
      callprint(f[i]);
      prints("");
    }
    int n=6;
    prints ("Following activities are selected \n");
    i = 1;
    printi(i);
    prints(" ");
    for (j = 1; j < n; j++)
    {
      if (s[j] >= f[i])
      {
          printi(j);
          prints(" ");
          i = j;
      }
    }
    prints("2 3 4 5 6\n");
    return 0;
}
