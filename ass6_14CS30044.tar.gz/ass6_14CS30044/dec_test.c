int global1=9;
int printi(int num);
int prints(char * c);
int readi(int *eP);

int sub(int a, int b)
{
    return a-b;
}

int main()
{
    prints("Enter two numbers a and b:");
    int a, b, c, *err;
    err = &c;
    a = readi(err);
    b = readi(err);
    prints("a-b = ");
    int diff  = sub(a,b);
    printi(diff);
    return 0;
}