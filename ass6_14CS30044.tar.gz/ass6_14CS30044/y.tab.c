/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "3.0.4"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* Copy the first part of user declarations.  */
#line 4 "ass6_14CS30044.y" /* yacc.c:339  */
 /* C Declarations and Definitions */
#include <string>
#include <bits/stdc++.h>
using namespace std;
void yyerror(string s);
extern int yydebug;
extern int yylex();
#include "ass6_14CS30044_translator.h"
quadarray qar;
symtab symtabvar;
symtab *ST = &(symtabvar);
vector<string> stringnames;
int strct=0;

#line 81 "y.tab.c" /* yacc.c:339  */

# ifndef YY_NULLPTR
#  if defined __cplusplus && 201103L <= __cplusplus
#   define YY_NULLPTR nullptr
#  else
#   define YY_NULLPTR 0
#  endif
# endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* In a future release of Bison, this section will be replaced
   by #include "y.tab.h".  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    SIZEOF_KEYWORD = 258,
    POINTER_OP = 259,
    INCREMENT_OP = 260,
    DECREMENT_OP = 261,
    LEFT_SHIFT_OP = 262,
    RIGHT_SHIFT_OP = 263,
    LESS_EQUAL_OP = 264,
    GREATER_EQUAL_OP = 265,
    EQUAL_OP = 266,
    NOT_EQUAL_OP = 267,
    LOGICAL_AND_OP = 268,
    LOGICAL_OR_OP = 269,
    MUL_ASSIGN = 270,
    DIV_ASSIGN = 271,
    MOD_ASSIGN = 272,
    ADD_ASSIGN = 273,
    SUB_ASSIGN = 274,
    LEFT_SHIFT_ASSIGN = 275,
    RIGHT_SHIFT_ASSIGN = 276,
    AND_ASSIGN = 277,
    XOR_ASSIGN = 278,
    OR_ASSIGN = 279,
    TYPE_NAME = 280,
    TYPEDEF_KEYWORD = 281,
    EXTERN_KEYWORD = 282,
    STATIC_KEYWORD = 283,
    AUTO_KEYWORD = 284,
    REGISTER_KEYWORD = 285,
    CHAR_KEYWORD = 286,
    SHORT_KEYWORD = 287,
    INT_KEYWORD = 288,
    LONG_KEYWORD = 289,
    SIGNED_KEYWORD = 290,
    UNSIGNED_KEYWORD = 291,
    FLOAT_KEYWORD = 292,
    DOUBLE_KEYWORD = 293,
    CONST_KEYWORD = 294,
    RESTRICT_KEYWORD = 295,
    VOLATILE_KEYWORD = 296,
    VOID_KEYWORD = 297,
    BOOL_KEYWORD = 298,
    COMPLEX_KEYWORD = 299,
    IMAGINARY_KEYWORD = 300,
    INLINE_KEYWORD = 301,
    STRUCT_KEYWORD = 302,
    UNION_KEYWORD = 303,
    ENUM_KEYWORD = 304,
    ELLIPSIS = 305,
    CASE_KEYWORD = 306,
    DEFAULT_KEYWORD = 307,
    IF_KEYWORD = 308,
    ELSE_KEYWORD = 309,
    SWITCH_KEYWORD = 310,
    WHILE_KEYWORD = 311,
    DO_KEYWORD = 312,
    FOR_KEYWORD = 313,
    GOTO_KEYWORD = 314,
    CONTINUE_KEYWORD = 315,
    BREAK_KEYWORD = 316,
    RETURN_KEYWORD = 317,
    STRING_LITERAL = 318,
    IDENTIFIER = 319,
    INTEGER_CONSTANT = 320,
    FLOAT_CONSTANT = 321,
    CHAR_CONSTANT = 322
  };
#endif
/* Tokens.  */
#define SIZEOF_KEYWORD 258
#define POINTER_OP 259
#define INCREMENT_OP 260
#define DECREMENT_OP 261
#define LEFT_SHIFT_OP 262
#define RIGHT_SHIFT_OP 263
#define LESS_EQUAL_OP 264
#define GREATER_EQUAL_OP 265
#define EQUAL_OP 266
#define NOT_EQUAL_OP 267
#define LOGICAL_AND_OP 268
#define LOGICAL_OR_OP 269
#define MUL_ASSIGN 270
#define DIV_ASSIGN 271
#define MOD_ASSIGN 272
#define ADD_ASSIGN 273
#define SUB_ASSIGN 274
#define LEFT_SHIFT_ASSIGN 275
#define RIGHT_SHIFT_ASSIGN 276
#define AND_ASSIGN 277
#define XOR_ASSIGN 278
#define OR_ASSIGN 279
#define TYPE_NAME 280
#define TYPEDEF_KEYWORD 281
#define EXTERN_KEYWORD 282
#define STATIC_KEYWORD 283
#define AUTO_KEYWORD 284
#define REGISTER_KEYWORD 285
#define CHAR_KEYWORD 286
#define SHORT_KEYWORD 287
#define INT_KEYWORD 288
#define LONG_KEYWORD 289
#define SIGNED_KEYWORD 290
#define UNSIGNED_KEYWORD 291
#define FLOAT_KEYWORD 292
#define DOUBLE_KEYWORD 293
#define CONST_KEYWORD 294
#define RESTRICT_KEYWORD 295
#define VOLATILE_KEYWORD 296
#define VOID_KEYWORD 297
#define BOOL_KEYWORD 298
#define COMPLEX_KEYWORD 299
#define IMAGINARY_KEYWORD 300
#define INLINE_KEYWORD 301
#define STRUCT_KEYWORD 302
#define UNION_KEYWORD 303
#define ENUM_KEYWORD 304
#define ELLIPSIS 305
#define CASE_KEYWORD 306
#define DEFAULT_KEYWORD 307
#define IF_KEYWORD 308
#define ELSE_KEYWORD 309
#define SWITCH_KEYWORD 310
#define WHILE_KEYWORD 311
#define DO_KEYWORD 312
#define FOR_KEYWORD 313
#define GOTO_KEYWORD 314
#define CONTINUE_KEYWORD 315
#define BREAK_KEYWORD 316
#define RETURN_KEYWORD 317
#define STRING_LITERAL 318
#define IDENTIFIER 319
#define INTEGER_CONSTANT 320
#define FLOAT_CONSTANT 321
#define CHAR_CONSTANT 322

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 20 "ass6_14CS30044.y" /* yacc.c:355  */

    opcode op;                     // to store opcode of non terminal
    int ival;                       // to store integer value
    string *str;                    // pointer to a string
    double dval;                    // to store double value
    void* ptr;                      // to store pointer value
    symtype *typeinfo;              // keeps info of all the types
    vector<param*> *prm_list;       // holds a list of parameters
    symdata *symdat;                // a pointer to an entry in the symbol table
    basic_type btype;              // a basic type enum
    decc *dec_info;                 // holds info on declartors
    char cval;                      // to store the char vaue
    vector<decc*> *ivec;            // holds a list of declators
    param *prm;                     // holds parameters like name and type of a parameter
    expression_type *exp_info;                 // holds info like loc and type for an expression and truelist false list and next list for statements

#line 272 "y.tab.c" /* yacc.c:355  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */

/* Copy the second part of user declarations.  */

#line 289 "y.tab.c" /* yacc.c:358  */

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif

#ifndef YY_ATTRIBUTE
# if (defined __GNUC__                                               \
      && (2 < __GNUC__ || (__GNUC__ == 2 && 96 <= __GNUC_MINOR__)))  \
     || defined __SUNPRO_C && 0x5110 <= __SUNPRO_C
#  define YY_ATTRIBUTE(Spec) __attribute__(Spec)
# else
#  define YY_ATTRIBUTE(Spec) /* empty */
# endif
#endif

#ifndef YY_ATTRIBUTE_PURE
# define YY_ATTRIBUTE_PURE   YY_ATTRIBUTE ((__pure__))
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# define YY_ATTRIBUTE_UNUSED YY_ATTRIBUTE ((__unused__))
#endif

#if !defined _Noreturn \
     && (!defined __STDC_VERSION__ || __STDC_VERSION__ < 201112)
# if defined _MSC_VER && 1200 <= _MSC_VER
#  define _Noreturn __declspec (noreturn)
# else
#  define _Noreturn YY_ATTRIBUTE ((__noreturn__))
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(E) ((void) (E))
#else
# define YYUSE(E) /* empty */
#endif

#if defined __GNUC__ && 407 <= __GNUC__ * 100 + __GNUC_MINOR__
/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN \
    _Pragma ("GCC diagnostic push") \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")\
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# define YY_IGNORE_MAYBE_UNINITIALIZED_END \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif


#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYSIZE_T yynewbytes;                                            \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / sizeof (*yyptr);                          \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, (Count) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYSIZE_T yyi;                         \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  52
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1048

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  92
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  69
/* YYNRULES -- Number of rules.  */
#define YYNRULES  214
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  367

/* YYTRANSLATE[YYX] -- Symbol number corresponding to YYX as returned
   by yylex, with out-of-bounds checking.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   322

#define YYTRANSLATE(YYX)                                                \
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, without out-of-bounds checking.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    78,     2,     2,     2,    85,    73,     2,
      68,    69,    74,    75,    72,    76,    81,    84,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    87,    91,
      71,    88,    70,    86,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    79,     2,    80,    89,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    82,    90,    83,    77,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67
};

#if YYDEBUG
  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,    96,    96,   106,   115,   139,   146,   157,   168,   179,
     188,   193,   194,   224,   254,   284,   317,   327,   340,   341,
     358,   387,   405,   406,   410,   411,   412,   413,   414,   415,
     419,   420,   424,   425,   448,   474,   475,   476,   519,   542,
     543,   544,   565,   586,   587,   592,   593,   617,   644,   657,
     680,   703,   731,   732,   762,   793,   794,   826,   827,   859,
     860,   898,   899,   900,   901,   902,   903,   904,   905,   906,
     907,   908,   912,   913,   916,   920,   921,   946,   947,   973,
     974,  1002,  1003,  1077,  1078,  1079,  1080,  1088,  1100,  1101,
    1125,  1126,  1127,  1128,  1129,  1130,  1131,  1132,  1136,  1137,
    1138,  1139,  1140,  1141,  1142,  1143,  1144,  1145,  1146,  1147,
    1148,  1149,  1153,  1154,  1155,  1156,  1159,  1160,  1161,  1162,
    1163,  1166,  1167,  1170,  1171,  1174,  1177,  1178,  1179,  1182,
    1184,  1185,  1190,  1195,  1196,  1197,  1198,  1204,  1205,  1226,
    1234,  1239,  1248,  1252,  1255,  1256,  1257,  1258,  1259,  1264,
    1268,  1271,  1272,  1276,  1277,  1278,  1279,  1282,  1283,  1286,
    1287,  1290,  1291,  1296,  1297,  1298,  1299,  1303,  1307,  1311,
    1314,  1315,  1322,  1323,  1324,  1325,  1326,  1327,  1330,  1331,
    1332,  1336,  1340,  1344,  1345,  1353,  1354,  1357,  1358,  1361,
    1362,  1365,  1378,  1379,  1393,  1394,  1397,  1398,  1402,  1406,
    1413,  1417,  1418,  1419,  1423,  1435,  1444,  1460,  1461,  1465,
    1466,  1470,  1471,  1480,  1484
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || 0
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "SIZEOF_KEYWORD", "POINTER_OP",
  "INCREMENT_OP", "DECREMENT_OP", "LEFT_SHIFT_OP", "RIGHT_SHIFT_OP",
  "LESS_EQUAL_OP", "GREATER_EQUAL_OP", "EQUAL_OP", "NOT_EQUAL_OP",
  "LOGICAL_AND_OP", "LOGICAL_OR_OP", "MUL_ASSIGN", "DIV_ASSIGN",
  "MOD_ASSIGN", "ADD_ASSIGN", "SUB_ASSIGN", "LEFT_SHIFT_ASSIGN",
  "RIGHT_SHIFT_ASSIGN", "AND_ASSIGN", "XOR_ASSIGN", "OR_ASSIGN",
  "TYPE_NAME", "TYPEDEF_KEYWORD", "EXTERN_KEYWORD", "STATIC_KEYWORD",
  "AUTO_KEYWORD", "REGISTER_KEYWORD", "CHAR_KEYWORD", "SHORT_KEYWORD",
  "INT_KEYWORD", "LONG_KEYWORD", "SIGNED_KEYWORD", "UNSIGNED_KEYWORD",
  "FLOAT_KEYWORD", "DOUBLE_KEYWORD", "CONST_KEYWORD", "RESTRICT_KEYWORD",
  "VOLATILE_KEYWORD", "VOID_KEYWORD", "BOOL_KEYWORD", "COMPLEX_KEYWORD",
  "IMAGINARY_KEYWORD", "INLINE_KEYWORD", "STRUCT_KEYWORD", "UNION_KEYWORD",
  "ENUM_KEYWORD", "ELLIPSIS", "CASE_KEYWORD", "DEFAULT_KEYWORD",
  "IF_KEYWORD", "ELSE_KEYWORD", "SWITCH_KEYWORD", "WHILE_KEYWORD",
  "DO_KEYWORD", "FOR_KEYWORD", "GOTO_KEYWORD", "CONTINUE_KEYWORD",
  "BREAK_KEYWORD", "RETURN_KEYWORD", "STRING_LITERAL", "IDENTIFIER",
  "INTEGER_CONSTANT", "FLOAT_CONSTANT", "CHAR_CONSTANT", "'('", "')'",
  "'>'", "'<'", "','", "'&'", "'*'", "'+'", "'-'", "'~'", "'!'", "'['",
  "']'", "'.'", "'{'", "'}'", "'/'", "'%'", "'?'", "':'", "'='", "'^'",
  "'|'", "';'", "$accept", "N", "M", "function_proto",
  "primary_expression", "relational_expression",
  "argument_expression_list", "unary_expression", "unary_operator",
  "cast_expression", "additive_expression", "postfix_expression",
  "shift_expression", "multiplicative_expression", "equality_expression",
  "logical_and_expression", "logical_or_expression",
  "conditional_expression", "assignment_operator", "expression",
  "constant_expression", "and_expression", "exclusive_or_expression",
  "inclusive_or_expression", "declaration", "jump_statement",
  "assignment_expression", "declaration_specifiers", "type_specifier",
  "specifier_qualifier_list", "enum_specifier", "enumerator_list",
  "enumerator", "enumeration_constant", "type_qualifier",
  "function_specifier", "declarator", "direct_declarator",
  "init_declarator_list", "init_declarator", "storage_class_specifier",
  "type_qualifier_list_opt", "assignment_expression_opt", "pointer",
  "type_qualifier_list", "parameter_type_list_opt", "parameter_type_list",
  "initializer_list", "designation", "designator_list", "designator",
  "statement", "labeled_statement", "compound_statement",
  "block_item_list", "block_item", "expression_statement",
  "expression_opt", "selection_statement", "parameter_list",
  "parameter_declaration", "identifier_list", "type_name", "initializer",
  "iteration_statement", "translation_unit", "external_declaration",
  "function_definition", "declaration_list", YY_NULLPTR
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[NUM] -- (External) token number corresponding to the
   (internal) symbol number NUM (which must be that of a token).  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,    40,    41,
      62,    60,    44,    38,    42,    43,    45,   126,    33,    91,
      93,    46,   123,   125,    47,    37,    63,    58,    61,    94,
     124,    59
};
# endif

#define YYPACT_NINF -301

#define yypact_value_is_default(Yystate) \
  (!!((Yystate) == (-301)))

#define YYTABLE_NINF -5

#define yytable_value_is_error(Yytable_value) \
  0

  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     977,  -301,  -301,  -301,  -301,  -301,  -301,  -301,  -301,  -301,
    -301,  -301,  -301,  -301,  -301,  -301,  -301,  -301,  -301,  -301,
    -301,  -301,  -301,    -6,   -53,  -301,    -2,   977,  -301,   977,
     977,   977,   886,  -301,  -301,   -39,    76,   274,  -301,  -301,
     124,   109,  -301,   803,     1,   -35,  -301,    92,  -301,  -301,
    -301,  -301,  -301,  -301,    76,  -301,    15,  -301,    97,   673,
     694,   694,   728,   102,   137,   142,  -301,  -301,   157,   135,
     136,   139,   442,  -301,   152,  -301,  -301,  -301,   628,  -301,
    -301,  -301,  -301,  -301,  -301,  -301,  -301,  -301,    21,    31,
     728,  -301,    20,    29,   172,     0,   223,   229,     2,  -301,
     -12,   180,   156,   162,  -301,  -301,  -301,    -2,  -301,  -301,
    -301,   171,  -301,  -301,  -301,  -301,   186,  -301,  -301,   109,
     542,  -301,   828,   911,   130,   124,  -301,     1,    51,     3,
    -301,   728,  -301,   628,  -301,   628,  -301,  -301,  -301,  -301,
     169,   421,   728,   728,   190,   421,   728,   168,  -301,  -301,
    -301,    -9,   421,   -27,   999,  -301,   999,   192,   728,   728,
     728,   728,  -301,  -301,  -301,  -301,  -301,  -301,  -301,  -301,
    -301,  -301,  -301,   728,  -301,   728,   728,   198,  -301,  -301,
     652,   728,   199,   728,   728,   728,   728,   728,   728,   728,
     251,    47,   728,  -301,   728,   728,   728,   177,  -301,   355,
    -301,  -301,  -301,   508,  -301,  -301,  -301,  -301,  -301,   124,
     197,  -301,   200,  -301,    70,   179,   749,   134,  -301,    41,
    -301,  -301,  -301,  -301,   201,   204,   421,  -301,   202,   112,
     728,  -301,   202,   184,  -301,  -301,  -301,  -301,  -301,  -301,
     574,   172,   172,   172,   172,  -301,     0,     0,  -301,  -301,
     131,  -301,   106,  -301,    20,    20,  -301,  -301,  -301,    21,
      21,  -301,  -301,  -301,  -301,   223,   180,   156,  -301,   728,
     212,    63,   542,    73,  -301,  -301,  -301,  -301,   951,  -301,
     214,   728,   179,   205,  -301,   209,   728,  -301,   208,   208,
    -301,   222,   421,   202,   225,  -301,   508,  -301,  -301,   728,
    -301,   728,   728,   728,   213,  -301,   461,  -301,  -301,  -301,
    -301,  -301,  -301,  -301,   215,  -301,  -301,   241,  -301,  -301,
     253,   226,   728,    72,  -301,   162,  -301,   202,  -301,  -301,
     542,  -301,  -301,  -301,   421,  -301,   728,  -301,   487,  -301,
    -301,   251,   237,  -301,  -301,   421,   145,   252,  -301,  -301,
     290,  -301,   254,  -301,   728,  -301,  -301,   728,  -301,   421,
    -301,  -301,   259,  -301,  -301,   421,  -301
};

  /* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
     Performed when YYTABLE does not specify something else to do.  Zero
     means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,   107,   144,   145,   146,   147,   148,    99,   100,   101,
     102,   105,   106,   103,   104,   126,   127,   128,    98,   108,
     109,   110,   129,     0,     0,   210,     0,    92,   111,    94,
      96,    90,     0,   207,   209,   120,     0,     0,   212,   132,
       0,   153,    81,   142,   131,     0,   140,     0,    93,    95,
      97,    91,     1,   208,     0,   125,     0,   121,   123,     0,
       0,     0,     0,     0,     0,     0,     3,     3,     0,     0,
       0,     0,     0,     9,     5,     8,     6,     7,     0,    24,
      25,    26,    27,    28,    29,   182,   187,    35,    52,    30,
       0,    48,    45,    18,    11,    32,    75,    57,    59,    88,
       0,    77,    79,    55,   185,   177,    72,     0,   186,   172,
     173,     3,   183,   174,   175,   176,     0,   157,   155,   154,
       0,   213,     0,   160,   150,     0,    82,   130,     0,     0,
     116,     0,     5,     0,    22,     0,    21,    19,    30,    74,
       0,     0,     0,     0,     0,     0,   190,     0,    84,    85,
      86,     0,     0,     0,   113,   200,   115,     0,     0,     0,
       0,     0,    62,    63,    64,    65,    66,    67,    68,    69,
      70,    71,    61,     0,    20,     0,     0,     0,    42,    41,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   188,     0,     0,     0,   142,   181,     0,
     133,   158,   156,     0,   201,   143,   214,   211,   198,   197,
       0,   159,   161,   194,     0,   150,   152,   149,   141,     0,
     117,   118,   122,   124,     0,     0,     0,   180,     2,     0,
       0,     3,   189,     0,    83,    87,   178,    10,   112,   114,
       0,    15,    13,    12,    14,    89,    34,    33,    40,    36,
       0,    16,     0,    39,    46,    47,    51,    49,    50,    54,
      53,     3,     3,     3,    73,    76,    78,    80,   184,     0,
       0,     0,     0,     0,   168,   163,   196,   138,     0,   139,
       0,     0,   149,    25,   151,     0,     0,   119,    23,     0,
     179,     0,     0,     2,     0,     3,     0,    31,    37,     0,
      38,     0,     0,     0,     0,   171,     0,   202,   165,   167,
     169,   162,   195,   199,     0,   137,   136,     0,     3,   192,
       0,     0,   190,     0,    17,     2,     2,     2,   170,   203,
       0,   164,   134,   135,     0,     3,     0,     2,     0,    43,
      56,    58,     0,   166,     2,     0,     0,     0,    44,     3,
     193,   204,     0,     3,     0,     3,   205,   190,    60,     0,
       2,     2,     0,   191,     3,     0,   206
};

  /* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -301,   -77,   -67,  -301,  -301,    52,  -301,   -58,  -301,   -73,
      53,  -301,    48,    71,   159,    44,  -301,   -56,  -301,   -65,
    -116,   160,   158,    58,   -23,  -301,  -109,     9,    12,    68,
    -301,   308,  -104,  -301,   -13,  -301,   -16,   316,  -301,   239,
    -301,   151,  -301,   -15,  -106,  -301,  -301,    74,  -279,  -301,
      94,  -133,  -301,    -1,  -301,   170,  -301,  -300,  -301,  -301,
      90,  -301,    98,  -115,  -301,  -301,   339,  -301,  -301
};

  /* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,   190,   144,    24,    87,    88,   250,    89,    90,    91,
      92,    93,    94,    95,    96,    97,    98,    99,   173,   100,
     140,   101,   102,   103,    25,   105,   106,   107,    27,   155,
      28,    56,    57,    58,    29,    30,   197,    44,    45,    46,
      31,   216,   285,    47,   119,   210,   211,   271,   272,   273,
     274,   108,   109,   110,   111,   112,   113,   233,   114,   212,
     213,   214,   157,   275,   115,    32,    33,    34,   122
};

  /* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule whose
     number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     145,   134,   136,   137,   138,   205,   139,   151,   227,    26,
      43,   204,   231,   153,   104,   223,    -2,   174,   217,   236,
     121,   191,   337,    38,   116,   222,   118,   330,   117,    37,
     158,   159,   138,   177,   178,   179,    48,   125,    49,    50,
      51,    26,   237,    54,   199,   192,   162,   163,   164,   165,
     166,   167,   168,   169,   170,   171,   126,   360,    35,   330,
     192,   262,    39,   192,   245,   156,    40,    55,   153,   123,
     153,   251,    41,   138,   185,   139,    36,   228,   229,   193,
     124,   232,   235,   264,   186,   187,   221,   129,    -2,    42,
     154,   160,   161,   290,   204,   175,   176,   180,   130,   206,
     138,   138,   138,   138,   202,    55,   201,   284,   181,   282,
     182,   117,   256,   257,   258,   222,   252,   138,   138,   172,
     156,   207,   156,   219,   287,   138,   138,   138,   138,   138,
     138,   138,   209,   263,   220,   306,   138,   138,   138,   279,
      55,   156,   280,   156,   338,   154,   307,   154,    15,    16,
      17,   291,   269,   304,   270,   339,    39,   308,   215,   319,
      40,   309,   286,   204,   294,   293,   154,   297,   154,    15,
      16,    17,   314,    15,    16,    17,   104,   317,   192,   183,
     184,   292,   138,    41,   192,   131,   300,   204,    39,   141,
     324,   331,    40,   276,   301,   302,   303,   204,    41,   147,
     298,   344,   117,   299,   201,   142,   241,   242,   243,   244,
     143,   138,   351,   139,   352,   343,   320,   192,    15,    16,
      17,   204,   238,   331,   239,   146,   361,   148,   322,   204,
     149,   224,   366,   225,   188,   189,   254,   255,   327,   152,
     259,   260,    -2,   138,   138,   195,   246,   247,   340,   341,
     342,   334,   196,   194,   198,   200,   226,   232,   230,   234,
     347,   240,   248,   253,   261,   120,   277,   350,   345,   201,
     288,   346,   278,   289,   192,   295,   305,    59,   313,    60,
      61,   321,   354,   362,   363,   315,   357,   209,   359,   316,
     296,   318,   232,   328,   336,   332,   138,   365,   358,     1,
       2,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,   333,   335,    23,   349,    62,    63,    64,   364,    65,
      66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
      76,    77,    78,   353,   355,   356,   326,    79,    80,    81,
      82,    83,    84,   265,   267,   266,    37,    85,    59,   325,
      60,    61,   128,   127,   218,    86,   281,   310,   312,   268,
     323,    53,     0,     0,     0,     0,     0,     0,     0,     0,
       1,     2,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,     0,     0,    23,     0,    62,    63,    64,     0,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    59,     0,    60,    61,    79,    80,
      81,    82,    83,    84,     0,     0,     0,    37,     0,     0,
       0,     0,     0,     0,     0,    59,    86,    60,    61,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    59,     0,    60,    61,     0,     0,
       0,     0,    62,    63,    64,     0,    65,    66,    67,    68,
      69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
      59,     0,    60,    61,    79,    80,    81,    82,    83,    84,
       0,     0,     0,    37,     0,    73,   132,    75,    76,    77,
      78,    59,    86,    60,    61,    79,    80,    81,    82,    83,
      84,     0,     0,     0,    73,   132,    75,    76,    77,    78,
       0,     0,     0,   150,    79,    80,    81,    82,    83,    84,
     269,     0,   270,   203,   329,    59,     0,    60,    61,     0,
      73,   132,    75,    76,    77,    78,     0,     0,     0,     0,
      79,    80,    81,    82,    83,    84,   269,     0,   270,   203,
     348,    73,   132,    75,    76,    77,    78,    59,     0,    60,
      61,    79,    80,    81,    82,    83,    84,   269,     0,   270,
     203,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    73,   132,    75,    76,    77,
      78,     0,     0,     0,     0,    79,    80,    81,    82,    83,
      84,     0,     0,     0,   203,     0,     0,     0,     0,     0,
       0,    59,     0,    60,    61,     0,     0,    73,   132,    75,
      76,    77,    78,     0,     0,     0,     0,    79,    80,    81,
      82,    83,    84,     1,     0,    59,   296,    60,    61,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,     0,     0,    59,    23,    60,    61,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    73,   132,    75,    76,    77,    78,    59,     0,    60,
      61,    79,    80,    81,    82,    83,    84,     0,     0,     0,
       0,     0,     0,     0,     0,    73,   132,    75,    76,    77,
      78,   249,     0,     0,     0,    79,    80,    81,    82,    83,
      84,    59,     0,    60,    61,     0,    73,   132,    75,    76,
      77,   133,     0,     0,     0,     0,    79,    80,    81,    82,
      83,    84,    59,     0,    60,    61,     0,    73,   132,    75,
      76,    77,   135,     0,     0,     0,     0,    79,    80,    81,
      82,    83,    84,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    73,   132,    75,    76,    77,    78,     0,     0,     0,
       0,    79,    80,    81,    82,    83,    84,     0,     0,     0,
       0,     0,    73,   132,    75,    76,    77,    78,     0,     0,
       0,     0,    79,   283,    81,    82,    83,    84,     1,     2,
       3,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
       0,     0,    23,     1,     2,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    17,
      18,    19,    20,    21,    22,     0,     0,    23,     0,     0,
       0,     0,     0,     0,     0,    -4,    52,     0,     0,     0,
       0,   120,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      37,     1,     2,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
      20,    21,    22,     0,     0,    23,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,     0,     0,
      23,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   208,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,     0,     0,
      23,   311,     1,     2,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,     1,     0,    23,     0,     0,     0,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,     0,     0,     0,    23
};

static const yytype_int16 yycheck[] =
{
      67,    59,    60,    61,    62,   120,    62,    72,   141,     0,
      26,   120,   145,    78,    37,   131,    14,    90,   124,   152,
      43,    98,   322,    24,    40,   129,    41,   306,    41,    82,
       9,    10,    90,     4,     5,     6,    27,    72,    29,    30,
      31,    32,    69,    82,   111,    72,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    91,   357,    64,   338,
      72,    14,    64,    72,   173,    78,    68,    64,   133,    68,
     135,   180,    74,   131,    74,   131,    82,   142,   143,    91,
      79,   146,    91,   192,    84,    85,    83,    72,    86,    91,
      78,    70,    71,   226,   203,    75,    76,    68,    83,   122,
     158,   159,   160,   161,   119,    64,   119,   216,    79,   215,
      81,   124,   185,   186,   187,   219,   181,   175,   176,    88,
     133,   122,   135,    72,    83,   183,   184,   185,   186,   187,
     188,   189,   123,    86,    83,    72,   194,   195,   196,    69,
      64,   154,    72,   156,    72,   133,    83,   135,    39,    40,
      41,   228,    79,   269,    81,    83,    64,   272,    28,   292,
      68,    88,    28,   272,   231,   230,   154,   240,   156,    39,
      40,    41,   281,    39,    40,    41,   199,   286,    72,     7,
       8,    69,   240,    74,    72,    88,    80,   296,    64,    87,
     299,   306,    68,   209,   261,   262,   263,   306,    74,    64,
      69,   334,   215,    72,   217,    68,   158,   159,   160,   161,
      68,   269,   345,   269,    69,   330,   293,    72,    39,    40,
      41,   330,   154,   338,   156,    68,   359,    91,   295,   338,
      91,   133,   365,   135,    11,    12,   183,   184,   303,    87,
     188,   189,    13,   301,   302,    89,   175,   176,   325,   326,
     327,   318,    90,    73,    83,    69,    87,   322,    68,    91,
     337,    69,    64,    64,    13,    88,    69,   344,   335,   282,
      69,   336,    72,    69,    72,    91,    64,     3,    64,     5,
       6,    56,   349,   360,   361,    80,   353,   278,   355,    80,
      82,    69,   357,    80,    68,    80,   354,   364,   354,    25,
      26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
      36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
      46,    80,    69,    49,    87,    51,    52,    53,    69,    55,
      56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
      66,    67,    68,    91,    54,    91,   302,    73,    74,    75,
      76,    77,    78,   194,   196,   195,    82,    83,     3,   301,
       5,     6,    54,    47,   125,    91,   215,   273,   278,   199,
     296,    32,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    -1,    -1,    49,    -1,    51,    52,    53,    -1,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,     3,    -1,     5,     6,    73,    74,
      75,    76,    77,    78,    -1,    -1,    -1,    82,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,     3,    91,     5,     6,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,     3,    -1,     5,     6,    -1,    -1,
      -1,    -1,    51,    52,    53,    -1,    55,    56,    57,    58,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
       3,    -1,     5,     6,    73,    74,    75,    76,    77,    78,
      -1,    -1,    -1,    82,    -1,    63,    64,    65,    66,    67,
      68,     3,    91,     5,     6,    73,    74,    75,    76,    77,
      78,    -1,    -1,    -1,    63,    64,    65,    66,    67,    68,
      -1,    -1,    -1,    91,    73,    74,    75,    76,    77,    78,
      79,    -1,    81,    82,    83,     3,    -1,     5,     6,    -1,
      63,    64,    65,    66,    67,    68,    -1,    -1,    -1,    -1,
      73,    74,    75,    76,    77,    78,    79,    -1,    81,    82,
      83,    63,    64,    65,    66,    67,    68,     3,    -1,     5,
       6,    73,    74,    75,    76,    77,    78,    79,    -1,    81,
      82,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    63,    64,    65,    66,    67,
      68,    -1,    -1,    -1,    -1,    73,    74,    75,    76,    77,
      78,    -1,    -1,    -1,    82,    -1,    -1,    -1,    -1,    -1,
      -1,     3,    -1,     5,     6,    -1,    -1,    63,    64,    65,
      66,    67,    68,    -1,    -1,    -1,    -1,    73,    74,    75,
      76,    77,    78,    25,    -1,     3,    82,     5,     6,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    -1,    -1,     3,    49,     5,     6,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    63,    64,    65,    66,    67,    68,     3,    -1,     5,
       6,    73,    74,    75,    76,    77,    78,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    63,    64,    65,    66,    67,
      68,    69,    -1,    -1,    -1,    73,    74,    75,    76,    77,
      78,     3,    -1,     5,     6,    -1,    63,    64,    65,    66,
      67,    68,    -1,    -1,    -1,    -1,    73,    74,    75,    76,
      77,    78,     3,    -1,     5,     6,    -1,    63,    64,    65,
      66,    67,    68,    -1,    -1,    -1,    -1,    73,    74,    75,
      76,    77,    78,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    63,    64,    65,    66,    67,    68,    -1,    -1,    -1,
      -1,    73,    74,    75,    76,    77,    78,    -1,    -1,    -1,
      -1,    -1,    63,    64,    65,    66,    67,    68,    -1,    -1,
      -1,    -1,    73,    74,    75,    76,    77,    78,    25,    26,
      27,    28,    29,    30,    31,    32,    33,    34,    35,    36,
      37,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      -1,    -1,    49,    25,    26,    27,    28,    29,    30,    31,
      32,    33,    34,    35,    36,    37,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    -1,    -1,    49,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    82,     0,    -1,    -1,    -1,
      -1,    88,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      82,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    -1,    -1,    49,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    -1,    -1,
      49,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    64,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    -1,    -1,
      49,    50,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    25,    -1,    49,    -1,    -1,    -1,
      31,    32,    33,    34,    35,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    -1,    -1,    -1,    49
};

  /* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      34,    35,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    46,    49,    95,   116,   119,   120,   122,   126,
     127,   132,   157,   158,   159,    64,    82,    82,   145,    64,
      68,    74,    91,   128,   129,   130,   131,   135,   119,   119,
     119,   119,     0,   158,    82,    64,   123,   124,   125,     3,
       5,     6,    51,    52,    53,    55,    56,    57,    58,    59,
      60,    61,    62,    63,    64,    65,    66,    67,    68,    73,
      74,    75,    76,    77,    78,    83,    91,    96,    97,    99,
     100,   101,   102,   103,   104,   105,   106,   107,   108,   109,
     111,   113,   114,   115,   116,   117,   118,   119,   143,   144,
     145,   146,   147,   148,   150,   156,   128,   126,   135,   136,
      88,   116,   160,    68,    79,    72,    91,   129,   123,    72,
      83,    88,    64,    68,    99,    68,    99,    99,    99,   109,
     112,    87,    68,    68,    94,    94,    68,    64,    91,    91,
      91,   111,    87,   111,   120,   121,   126,   154,     9,    10,
      70,    71,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,    88,   110,   101,    75,    76,     4,     5,     6,
      68,    79,    81,     7,     8,    74,    84,    85,    11,    12,
      93,    93,    72,    91,    73,    89,    90,   128,    83,    94,
      69,   126,   135,    82,   118,   155,   116,   145,    64,   119,
     137,   138,   151,   152,   153,    28,   133,   136,   131,    72,
      83,    83,   124,   112,   154,   154,    87,   143,   111,   111,
      68,   143,   111,   149,    91,    91,   143,    69,   121,   121,
      69,   104,   104,   104,   104,   118,   105,   105,    64,    69,
      98,   118,   111,    64,   102,   102,   101,   101,   101,    97,
      97,    13,    14,    86,   118,   106,   113,   114,   147,    79,
      81,   139,   140,   141,   142,   155,   128,    69,    72,    69,
      72,   133,   136,    74,   118,   134,    28,    83,    69,    69,
     143,    93,    69,   111,    94,    91,    82,   101,    69,    72,
      80,    94,    94,    94,   112,    64,    72,    83,   155,    88,
     142,    50,   152,    64,   118,    80,    80,   118,    69,   143,
      93,    56,    94,   139,   118,   115,   107,   111,    80,    83,
     140,   155,    80,    80,    94,    69,    68,   149,    72,    83,
      93,    93,    93,   155,   143,    94,   111,    93,    83,    87,
      93,   143,    69,    91,    94,    54,    91,    94,   109,    94,
     149,   143,    93,    93,    69,    94,   143
};

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    92,    93,    94,    95,    96,    96,    96,    96,    96,
      96,    97,    97,    97,    97,    97,    98,    98,    99,    99,
      99,    99,    99,    99,   100,   100,   100,   100,   100,   100,
     101,   101,   102,   102,   102,   103,   103,   103,   103,   103,
     103,   103,   103,   103,   103,   104,   104,   104,   105,   105,
     105,   105,   106,   106,   106,   107,   107,   108,   108,   109,
     109,   110,   110,   110,   110,   110,   110,   110,   110,   110,
     110,   110,   111,   111,   112,   113,   113,   114,   114,   115,
     115,   116,   116,   117,   117,   117,   117,   117,   118,   118,
     119,   119,   119,   119,   119,   119,   119,   119,   120,   120,
     120,   120,   120,   120,   120,   120,   120,   120,   120,   120,
     120,   120,   121,   121,   121,   121,   122,   122,   122,   122,
     122,   123,   123,   124,   124,   125,   126,   126,   126,   127,
     128,   128,   129,   129,   129,   129,   129,   129,   129,   129,
     130,   130,   131,   131,   132,   132,   132,   132,   132,   133,
     133,   134,   134,   135,   135,   135,   135,   136,   136,   137,
     137,   138,   138,   139,   139,   139,   139,   140,   141,   141,
     142,   142,   143,   143,   143,   143,   143,   143,   144,   144,
     144,   145,   145,   146,   146,   147,   147,   148,   148,   149,
     149,   150,   150,   150,   151,   151,   152,   152,   153,   153,
     154,   155,   155,   155,   156,   156,   156,   157,   157,   158,
     158,   159,   159,   160,   160
};

  /* YYR2[YYN] -- Number of symbols on the right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     0,     0,     2,     1,     1,     1,     1,     1,
       3,     1,     3,     3,     3,     3,     1,     3,     1,     2,
       2,     2,     2,     4,     1,     1,     1,     1,     1,     1,
       1,     4,     1,     3,     3,     1,     3,     4,     4,     3,
       3,     2,     2,     6,     7,     1,     3,     3,     1,     3,
       3,     3,     1,     3,     3,     1,     6,     1,     6,     1,
       9,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     3,     1,     1,     3,     1,     3,     1,
       3,     2,     3,     3,     2,     2,     2,     3,     1,     3,
       1,     2,     1,     2,     1,     2,     1,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     1,     2,     1,     4,     5,     5,     6,
       2,     1,     3,     1,     3,     1,     1,     1,     1,     1,
       2,     1,     1,     3,     6,     6,     5,     5,     4,     4,
       1,     3,     1,     3,     1,     1,     1,     1,     1,     1,
       0,     1,     0,     1,     2,     2,     3,     1,     2,     1,
       0,     1,     3,     1,     3,     2,     4,     2,     1,     2,
       3,     2,     1,     1,     1,     1,     1,     1,     3,     4,
       3,     3,     2,     1,     3,     1,     1,     1,     2,     1,
       0,    12,     5,     8,     1,     3,     2,     1,     1,     3,
       1,     1,     3,     4,     8,     9,    14,     1,     2,     1,
       1,     4,     2,     1,     2
};


#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)
#define YYEMPTY         (-2)
#define YYEOF           0

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                  \
do                                                              \
  if (yychar == YYEMPTY)                                        \
    {                                                           \
      yychar = (Token);                                         \
      yylval = (Value);                                         \
      YYPOPSTACK (yylen);                                       \
      yystate = *yyssp;                                         \
      goto yybackup;                                            \
    }                                                           \
  else                                                          \
    {                                                           \
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;                                                  \
    }                                                           \
while (0)

/* Error token number */
#define YYTERROR        1
#define YYERRCODE       256



/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)

/* This macro is provided for backward compatibility. */
#ifndef YY_LOCATION_PRINT
# define YY_LOCATION_PRINT(File, Loc) ((void) 0)
#endif


# define YY_SYMBOL_PRINT(Title, Type, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Type, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*----------------------------------------.
| Print this symbol's value on YYOUTPUT.  |
`----------------------------------------*/

static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  FILE *yyo = yyoutput;
  YYUSE (yyo);
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  YYUSE (yytype);
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyoutput, "%s %s (",
             yytype < YYNTOKENS ? "token" : "nterm", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yytype_int16 *yyssp, YYSTYPE *yyvsp, int yyrule)
{
  unsigned long int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       yystos[yyssp[yyi + 1 - yynrhs]],
                       &(yyvsp[(yyi + 1) - (yynrhs)])
                                              );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
yystrlen (const char *yystr)
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
yystpcpy (char *yydest, const char *yysrc)
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
        switch (*++yyp)
          {
          case '\'':
          case ',':
            goto do_not_strip_quotes;

          case '\\':
            if (*++yyp != '\\')
              goto do_not_strip_quotes;
            /* Fall through.  */
          default:
            if (yyres)
              yyres[yyn] = *yyp;
            yyn++;
            break;

          case '"':
            if (yyres)
              yyres[yyn] = '\0';
            return yyn;
          }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (YY_NULLPTR, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = YY_NULLPTR;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                {
                  YYSIZE_T yysize1 = yysize + yytnamerr (YY_NULLPTR, yytname[yyx]);
                  if (! (yysize <= yysize1
                         && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                    return 2;
                  yysize = yysize1;
                }
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  {
    YYSIZE_T yysize1 = yysize + yystrlen (yyformat);
    if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
      return 2;
    yysize = yysize1;
  }

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
{
  YYUSE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YYUSE (yytype);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}




/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       'yyss': related to states.
       'yyvs': related to semantic values.

       Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken = 0;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yyssp = yyss = yyssa;
  yyvsp = yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */
  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        YYSTYPE *yyvs1 = yyvs;
        yytype_int16 *yyss1 = yyss;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * sizeof (*yyssp),
                    &yyvs1, yysize * sizeof (*yyvsp),
                    &yystacksize);

        yyss = yyss1;
        yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yytype_int16 *yyss1 = yyss;
        union yyalloc *yyptr =
          (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
        if (! yyptr)
          goto yyexhaustedlab;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
                  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 96 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
    (yyval.exp_info) =  new expression_type;  
    (yyval.exp_info)->nextlist = makelist(qar.nextinstr); 
    qar.emit("","",OP_GOTO,"");
}
#line 1805 "y.tab.c" /* yacc.c:1646  */
    break;

  case 3:
#line 106 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
    (yyval.exp_info) =  new expression_type; 
    (yyval.exp_info)->instr = qar.nextinstr; 
}
#line 1814 "y.tab.c" /* yacc.c:1646  */
    break;

  case 4:
#line 116 "ass6_14CS30044.y" /* yacc.c:1646  */
    {       
        basic_type type_now = (yyvsp[-1].btype);
        int temp_size = -1;
        if(type_now == type_char) temp_size = SIZE_CHAR;
        if(type_now == type_int)  temp_size = SIZE_INT;
        if(type_now == type_double)  temp_size = SIZE_DOUBLE;
        decc *my_dec = (yyvsp[0].dec_info);
        symdata *var = symtabvar.lookup(my_dec->name);
        if(my_dec->btype)
        {
            symdata *retval = var->nested_symtab->lookup("retVal",type_now,my_dec->pc);
            var->offset = ST->offset;
            var->size = 0;
        }
        var->init_val = NULL;       
        (yyval.dec_info)=(yyvsp[0].dec_info); 
    }
#line 1836 "y.tab.c" /* yacc.c:1646  */
    break;

  case 5:
#line 140 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        string xy = (*((yyvsp[0].str))); 
        ST->lookup(xy);
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->loc = xy;
    }
#line 1847 "y.tab.c" /* yacc.c:1646  */
    break;

  case 6:
#line 147 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symval *t = new symval; 
        t->setval((yyvsp[0].dval));
        (yyval.exp_info) = new expression_type; 
        int temp;
        (yyval.exp_info)->loc = ST->gentemp(temp, type_double);
        qar.emit((yyval.exp_info)->loc, (yyvsp[0].dval), ASSIGN);
        double stard;
        ST->lookup((yyval.exp_info)->loc)->init_val = t;
    }
#line 1862 "y.tab.c" /* yacc.c:1646  */
    break;

  case 7:
#line 158 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symval *t = new symval; 
        t->setval((yyvsp[0].cval)); 
        (yyval.exp_info) = new expression_type;
        int temp;
        double stard;
        (yyval.exp_info)->loc = ST->gentemp(temp, type_char); 
        qar.emit((yyval.exp_info)->loc, (yyvsp[0].cval), ASSIGN); 
        ST->lookup((yyval.exp_info)->loc)->init_val = t;
    }
#line 1877 "y.tab.c" /* yacc.c:1646  */
    break;

  case 8:
#line 169 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symval *t = new symval;
        t->setval((yyvsp[0].ival));
        double stard;
        (yyval.exp_info) = new expression_type; 
        int temp;
        (yyval.exp_info)->loc = ST->gentemp(temp, type_int);
        qar.emit((yyval.exp_info)->loc, (yyvsp[0].ival), ASSIGN);
        ST->lookup((yyval.exp_info)->loc)->init_val = t; 
    }
#line 1892 "y.tab.c" /* yacc.c:1646  */
    break;

  case 9:
#line 180 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new expression_type;
        stringstream ss;
        ss<<".LC"<<strct;
        ss>>(yyval.exp_info)->loc; 
        strct++;
        stringnames.push_back(*(yyvsp[0].str));
    }
#line 1905 "y.tab.c" /* yacc.c:1646  */
    break;

  case 10:
#line 188 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.exp_info) = (yyvsp[-1].exp_info);}
#line 1911 "y.tab.c" /* yacc.c:1646  */
    break;

  case 12:
#line 195 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type;
        int tempvar=90;
        double stard;
        (yyval.exp_info)->loc = ST->gentemp();
        (yyval.exp_info)->btype = type_bool;
        qar.emit((yyval.exp_info)->loc,"1",ASSIGN,""); 
        (yyval.exp_info)->truelist = makelist(qar.nextinstr); 
        qar.emit("",(yyvsp[-2].exp_info)->loc,IF_GREATER,(yyvsp[0].exp_info)->loc); 
        qar.emit((yyval.exp_info)->loc,"0",ASSIGN,"");  
        (yyval.exp_info)->falselist = makelist(qar.nextinstr); 
        qar.emit("","",OP_GOTO,"");
    }
#line 1945 "y.tab.c" /* yacc.c:1646  */
    break;

  case 13:
#line 225 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        int tempvar=90;
        double stad=1.09;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->loc = ST->gentemp();
        (yyval.exp_info)->btype = type_bool; 
        qar.emit((yyval.exp_info)->loc,"1",ASSIGN,""); 
        (yyval.exp_info)->truelist = makelist(qar.nextinstr); 
        qar.emit("",(yyvsp[-2].exp_info)->loc,IF_GREATER_OR_EQUAL,(yyvsp[0].exp_info)->loc); 
        qar.emit((yyval.exp_info)->loc,"0",ASSIGN,"");  
        (yyval.exp_info)->falselist = makelist(qar.nextinstr); 
        qar.emit("","",OP_GOTO,"");
    }
#line 1979 "y.tab.c" /* yacc.c:1646  */
    break;

  case 14:
#line 255 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        int tempvar=90;
        double stard=1.09;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->loc = ST->gentemp();
        (yyval.exp_info)->btype = type_bool;
        qar.emit((yyval.exp_info)->loc,"1",ASSIGN,""); 
        (yyval.exp_info)->truelist = makelist(qar.nextinstr); 
        qar.emit("",(yyvsp[-2].exp_info)->loc,IF_LESS,(yyvsp[0].exp_info)->loc); 
        qar.emit((yyval.exp_info)->loc,"0",ASSIGN,"");  
        (yyval.exp_info)->falselist = makelist(qar.nextinstr); 
        qar.emit("","",OP_GOTO,"");
    }
#line 2013 "y.tab.c" /* yacc.c:1646  */
    break;

  case 15:
#line 285 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        int tempvar=90;
        double stard=1.09;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->loc = ST->gentemp();
        (yyval.exp_info)->btype = type_bool; 
        qar.emit((yyval.exp_info)->loc,"1",ASSIGN,""); 
        (yyval.exp_info)->truelist = makelist(qar.nextinstr); 
        qar.emit("",(yyvsp[-2].exp_info)->loc,IF_LESS_OR_EQUAL,(yyvsp[0].exp_info)->loc); 
        qar.emit((yyval.exp_info)->loc,"0",ASSIGN,"");  
        (yyval.exp_info)->falselist = makelist(qar.nextinstr); 
        qar.emit("","",OP_GOTO,"");
    }
#line 2047 "y.tab.c" /* yacc.c:1646  */
    break;

  case 16:
#line 318 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        param *t = new param; 
        t->name = (yyvsp[0].exp_info)->loc; 
        if(t->name[0]!='.')
            t->type = ST->lookup(t->name)->type; 
        double stard;
        (yyval.prm_list) = new vector<param*>; 
        (yyval.prm_list)->push_back(t);
    }
#line 2061 "y.tab.c" /* yacc.c:1646  */
    break;

  case 17:
#line 328 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        param *t = new param; 
        t->name = (yyvsp[0].exp_info)->loc; 
        if(t->name[0]!='.')
            t->type = ST->lookup(t->name)->type; 
        double stard;
        (yyval.prm_list) = (yyvsp[-2].prm_list); 
        (yyval.prm_list)->push_back(t);
    }
#line 2075 "y.tab.c" /* yacc.c:1646  */
    break;

  case 19:
#line 342 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype ty = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        int tempvar=90;
        if(ty.btype == type_array)
        {
            string t = ST->gentemp(ty.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            qar.emit(t,t,MINUS,"1"); 
            qar.emit((yyvsp[0].exp_info)->loc,t,ARRAY_INDEX_TO,*((yyvsp[0].exp_info)->folder));
        }
        else
            qar.emit((yyvsp[0].exp_info)->loc,(yyvsp[0].exp_info)->loc,MINUS,"1");
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->loc = ST->gentemp(ST->lookup((yyvsp[0].exp_info)->loc)->type.btype); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[0].exp_info)->loc,ASSIGN,""); 
    }
#line 2096 "y.tab.c" /* yacc.c:1646  */
    break;

  case 20:
#line 359 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        int tempvar=90;
        //cout<<"line 362"<<endl;
        if((yyvsp[-1].op) == REFERENCE)
        {
            (yyval.exp_info) = new expression_type; 
            (yyval.exp_info)->loc = ST->gentemp();
            qar.emit((yyval.exp_info)->loc,(yyvsp[0].exp_info)->loc,REFERENCE,"");
        }
        else if((yyvsp[-1].op) == DEREFERENCE)
        {
          //  cout<<"line 372"<<endl;
            (yyval.exp_info) = new expression_type; 
            (yyval.exp_info)->loc = ST->gentemp();
            qar.emit((yyval.exp_info)->loc,(yyvsp[0].exp_info)->loc,DEREFERENCE,"");
        }
        else if((yyvsp[-1].op) == UNARY_MINUS)
        {
          //  cout<<"line 378"<<endl;
            (yyval.exp_info) = new expression_type; 
            (yyval.exp_info)->loc = ST->gentemp();
            qar.emit((yyval.exp_info)->loc,(yyvsp[0].exp_info)->loc,UNARY_MINUS,"");
        }
        else
        {
            (yyval.exp_info) = (yyvsp[0].exp_info);//cout<<"line 384"<<endl;
        }
    }
#line 2129 "y.tab.c" /* yacc.c:1646  */
    break;

  case 21:
#line 388 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype ty = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        int tempvar=90;
        double stard=1.09;
        if(ty.btype == type_array)
        {
            string t = ST->gentemp(ty.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            qar.emit(t,t,PLUS,"1"); 
            qar.emit((yyvsp[0].exp_info)->loc,t,ARRAY_INDEX_TO,*((yyvsp[0].exp_info)->folder));
        }
        else
            qar.emit((yyvsp[0].exp_info)->loc,(yyvsp[0].exp_info)->loc,PLUS,"1"); 
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->loc = ST->gentemp(ST->lookup((yyvsp[0].exp_info)->loc)->type.btype); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[0].exp_info)->loc,ASSIGN,""); 
    }
#line 2151 "y.tab.c" /* yacc.c:1646  */
    break;

  case 22:
#line 405 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2157 "y.tab.c" /* yacc.c:1646  */
    break;

  case 23:
#line 406 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2163 "y.tab.c" /* yacc.c:1646  */
    break;

  case 24:
#line 410 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.op) = REFERENCE;}
#line 2169 "y.tab.c" /* yacc.c:1646  */
    break;

  case 25:
#line 411 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.op) = DEREFERENCE;}
#line 2175 "y.tab.c" /* yacc.c:1646  */
    break;

  case 26:
#line 412 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.op) = UNARY_PLUS;}
#line 2181 "y.tab.c" /* yacc.c:1646  */
    break;

  case 27:
#line 413 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.op) = UNARY_MINUS;}
#line 2187 "y.tab.c" /* yacc.c:1646  */
    break;

  case 28:
#line 414 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.op) = COMPLEMENT;}
#line 2193 "y.tab.c" /* yacc.c:1646  */
    break;

  case 29:
#line 415 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.op) = NOT;}
#line 2199 "y.tab.c" /* yacc.c:1646  */
    break;

  case 31:
#line 420 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2205 "y.tab.c" /* yacc.c:1646  */
    break;

  case 33:
#line 426 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        basic_type final_type = max(ST->lookup((yyvsp[-2].exp_info)->loc)->type.btype, ST->lookup((yyvsp[0].exp_info)->loc)->type.btype); 
        (yyval.exp_info)->loc = ST->gentemp(final_type); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,MINUS,(yyvsp[0].exp_info)->loc);
    }
#line 2232 "y.tab.c" /* yacc.c:1646  */
    break;

  case 34:
#line 449 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        basic_type final_type = max(ST->lookup((yyvsp[-2].exp_info)->loc)->type.btype, ST->lookup((yyvsp[0].exp_info)->loc)->type.btype); 
        (yyval.exp_info)->loc = ST->gentemp(final_type); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,PLUS,(yyvsp[0].exp_info)->loc);
    }
#line 2259 "y.tab.c" /* yacc.c:1646  */
    break;

  case 37:
#line 477 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        string fname = (yyvsp[-3].exp_info)->loc;
        symtab *fsym = symtabvar.lookup(fname)->nested_symtab;
        vector<param*> arglist = *((yyvsp[-1].prm_list));
        vector<symdata*> paramlist = fsym->ord_sym;
        bool many = false;
        int temp;
        for(int i = 0;i < arglist.size(); i++)
        {
            /*if(arglist[i]->type.btype != paramlist[i]->type.btype)
            {
                double stard;
                string t = ST->gentemp(temp, paramlist[i]->type.btype);
                qar.conv2type(t,paramlist[i]->type.btype,arglist[i]->name,arglist[i]->type.btype);
                arglist[i]->name = t;
            }
            */
            if(paramlist[i]->name == "retVal")
            {
                many = true;
            }            
            qar.emit(arglist[i]->name,"",PARAM,"");
        }
        if(many==false && paramlist[arglist.size()]->name != "retval" )
        {

        }
        basic_type return_type = fsym->lookup("retVal")->type.btype;
        if(return_type == type_void)
            qar.emit(fname,(int)arglist.size(),CALL);
        else
        {
            string return_val = ST->gentemp(return_type);
            string temp; 
            stringstream ss;
            ss<<arglist.size(); 
            ss>>temp;
            qar.emit(fname,temp,CALL,return_val);
            (yyval.exp_info) = new expression_type; 
            (yyval.exp_info)->loc = return_val;
        }
    }
#line 2306 "y.tab.c" /* yacc.c:1646  */
    break;

  case 38:
#line 520 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t = ST->lookup((yyvsp[-3].exp_info)->loc)->type;
        string f;
        int temp;
        if( (yyvsp[-3].exp_info)->fold == 0)
        {
            f = ST->gentemp(temp, type_int);
            qar.emit(f,0,ASSIGN);
            (yyvsp[-3].exp_info)->folder = new string(f);
        }
        f = *((yyvsp[-3].exp_info)->folder);
        double stard;
        int mult = t.alist[(yyvsp[-3].exp_info)->fold]; 
        (yyvsp[-3].exp_info)->fold++;
        stringstream ss; 
        ss<<mult; 
        string m; 
        ss>>m;
        qar.emit(f,f,MULT,m);
        qar.emit(f,f,PLUS,(yyvsp[-1].exp_info)->loc);
        (yyval.exp_info) = (yyvsp[-3].exp_info);
    }
#line 2333 "y.tab.c" /* yacc.c:1646  */
    break;

  case 41:
#line 545 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new expression_type; 
        int temp;
        double stard;
        (yyval.exp_info)->loc = ST->gentemp(temp, ST->lookup((yyvsp[-1].exp_info)->loc)->type.btype); 
        symtype ty = ST->lookup((yyvsp[-1].exp_info)->loc)->type;
        if(ty.btype == type_array)
        {
            string t = ST->gentemp(ty.base_t);
            qar.emit(t,(yyvsp[-1].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-1].exp_info)->folder));
            qar.emit((yyval.exp_info)->loc,t,ASSIGN,"");
            qar.emit(t,t,MINUS,"1"); 
            qar.emit((yyvsp[-1].exp_info)->loc,t,ARRAY_INDEX_TO,*((yyvsp[-1].exp_info)->folder));
        }
        else
        {
            qar.emit((yyval.exp_info)->loc,(yyvsp[-1].exp_info)->loc,ASSIGN,""); 
            qar.emit((yyvsp[-1].exp_info)->loc,(yyvsp[-1].exp_info)->loc,MINUS,"1");
        }
    }
#line 2358 "y.tab.c" /* yacc.c:1646  */
    break;

  case 42:
#line 566 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new expression_type; 
        int temp;
        double stard;
        (yyval.exp_info)->loc = ST->gentemp(temp, ST->lookup((yyvsp[-1].exp_info)->loc)->type.btype); 
        symtype ty = ST->lookup((yyvsp[-1].exp_info)->loc)->type;
        if(ty.btype == type_array)
        {
            string t = ST->gentemp(ty.base_t);
            qar.emit(t,(yyvsp[-1].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-1].exp_info)->folder));
            qar.emit((yyval.exp_info)->loc,t,ASSIGN,"");
            qar.emit(t,t,PLUS,"1"); 
            qar.emit((yyvsp[-1].exp_info)->loc,t,ARRAY_INDEX_TO,*((yyvsp[-1].exp_info)->folder));
        }
        else
        {
            qar.emit((yyval.exp_info)->loc,(yyvsp[-1].exp_info)->loc,ASSIGN,""); 
            qar.emit((yyvsp[-1].exp_info)->loc,(yyvsp[-1].exp_info)->loc,PLUS,"1");
        }
    }
#line 2383 "y.tab.c" /* yacc.c:1646  */
    break;

  case 43:
#line 586 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2389 "y.tab.c" /* yacc.c:1646  */
    break;

  case 44:
#line 587 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2395 "y.tab.c" /* yacc.c:1646  */
    break;

  case 46:
#line 594 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        int tempvar;
        double stard;
        (yyval.exp_info)->loc = ST->gentemp(ST->lookup((yyvsp[-2].exp_info)->loc)->type.btype); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,SHIFT_LEFT,(yyvsp[0].exp_info)->loc);
    }
#line 2423 "y.tab.c" /* yacc.c:1646  */
    break;

  case 47:
#line 618 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        int tempvar;
        double stard;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->loc = ST->gentemp(ST->lookup((yyvsp[-2].exp_info)->loc)->type.btype); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,SHIFT_RIGHT,(yyvsp[0].exp_info)->loc);
    }
#line 2451 "y.tab.c" /* yacc.c:1646  */
    break;

  case 48:
#line 645 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t1 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t1.base_t;
        }
        else
            (yyval.exp_info) = (yyvsp[0].exp_info);
    }
#line 2468 "y.tab.c" /* yacc.c:1646  */
    break;

  case 49:
#line 658 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        basic_type final_type = max(ST->lookup((yyvsp[-2].exp_info)->loc)->type.btype, ST->lookup((yyvsp[0].exp_info)->loc)->type.btype); 
        (yyval.exp_info)->loc = ST->gentemp(final_type); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,DIVIDE,(yyvsp[0].exp_info)->loc);
    }
#line 2495 "y.tab.c" /* yacc.c:1646  */
    break;

  case 50:
#line 681 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        basic_type final_type = max(ST->lookup((yyvsp[-2].exp_info)->loc)->type.btype, ST->lookup((yyvsp[0].exp_info)->loc)->type.btype); 
        (yyval.exp_info)->loc = ST->gentemp(final_type); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,MODULO,(yyvsp[0].exp_info)->loc);
    }
#line 2522 "y.tab.c" /* yacc.c:1646  */
    break;

  case 51:
#line 704 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        int tempvar=90;
        double stard=1.0;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        basic_type final_type = max(ST->lookup((yyvsp[-2].exp_info)->loc)->type.btype,ST->lookup((yyvsp[0].exp_info)->loc)->type.btype); 
        (yyval.exp_info)->loc = ST->gentemp(final_type); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,MULT,(yyvsp[0].exp_info)->loc);
    }
#line 2551 "y.tab.c" /* yacc.c:1646  */
    break;

  case 53:
#line 733 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        int tempvar=90;
        double stard=1.08;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->loc = ST->gentemp();
        (yyval.exp_info)->btype = type_bool; 
        qar.emit((yyval.exp_info)->loc,"1",ASSIGN,""); 
        (yyval.exp_info)->truelist = makelist(qar.nextinstr); 
        qar.emit("",(yyvsp[-2].exp_info)->loc,IF_NOT_EQUAL,(yyvsp[0].exp_info)->loc); 
        qar.emit((yyval.exp_info)->loc,"0",ASSIGN,""); 
        (yyval.exp_info)->falselist = makelist(qar.nextinstr);  
        qar.emit("","",OP_GOTO,"");
    }
#line 2585 "y.tab.c" /* yacc.c:1646  */
    break;

  case 54:
#line 763 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->loc = ST->gentemp();
        (yyval.exp_info)->btype = type_bool; 
        qar.emit((yyval.exp_info)->loc,"1",ASSIGN,""); 
        (yyval.exp_info)->truelist = makelist(qar.nextinstr); 
        qar.emit("",(yyvsp[-2].exp_info)->loc,IF_EQUAL,(yyvsp[0].exp_info)->loc); 
        qar.emit((yyval.exp_info)->loc,"0",ASSIGN,""); 
        (yyval.exp_info)->falselist = makelist(qar.nextinstr);  
        qar.emit("","",OP_GOTO,"");
    }
#line 2617 "y.tab.c" /* yacc.c:1646  */
    break;

  case 56:
#line 795 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t5 = ST->lookup((yyvsp[-1].exp_info)->loc)->type;
        int tempvar=56;
        double stard=12.67;
        if(t5.btype == type_array)
        {
            string t = ST->gentemp(t5.base_t);
            qar.emit(t,(yyvsp[-1].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-1].exp_info)->folder));
            (yyvsp[-1].exp_info)->loc = t; 
            (yyvsp[-1].exp_info)->btype = t5.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-5].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-5].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-5].exp_info)->folder));
            (yyvsp[-5].exp_info)->loc = t; 
            (yyvsp[-5].exp_info)->btype = t1.base_t;
        }       
        qar.backpatch((yyvsp[-4].exp_info)->nextlist,qar.nextinstr);
        qar.convInt2Bool((yyvsp[-5].exp_info));
        qar.backpatch((yyvsp[0].exp_info)->nextlist, qar.nextinstr);
        qar.convInt2Bool((yyvsp[-1].exp_info));
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->btype = type_bool;
        qar.backpatch((yyvsp[-5].exp_info)->truelist,(yyvsp[-2].exp_info)->instr); 
        (yyval.exp_info)->falselist = merge((yyvsp[-5].exp_info)->falselist, (yyvsp[-1].exp_info)->falselist); 
        (yyval.exp_info)->truelist = (yyvsp[-1].exp_info)->truelist; 
    }
#line 2651 "y.tab.c" /* yacc.c:1646  */
    break;

  case 58:
#line 828 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t5 = ST->lookup((yyvsp[-1].exp_info)->loc)->type;
        int tempvar=56;
        double stard=12.67;
        if(t5.btype == type_array)
        {
            string t = ST->gentemp(t5.base_t);
            qar.emit(t,(yyvsp[-1].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-1].exp_info)->folder));
            (yyvsp[-1].exp_info)->loc = t; 
            (yyvsp[-1].exp_info)->btype = t5.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-5].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-5].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-5].exp_info)->folder));
            (yyvsp[-5].exp_info)->loc = t; 
            (yyvsp[-5].exp_info)->btype = t1.base_t;
        }   
        qar.backpatch((yyvsp[-4].exp_info)->nextlist,qar.nextinstr);
        qar.convInt2Bool((yyvsp[-5].exp_info));
        qar.backpatch((yyvsp[0].exp_info)->nextlist, qar.nextinstr);
        qar.convInt2Bool((yyvsp[-1].exp_info));//cout<<"conv"<<qar.nextinstr<<endl; 
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->btype = type_bool;
        qar.backpatch((yyvsp[-5].exp_info)->falselist,(yyvsp[-2].exp_info)->instr); 
        (yyval.exp_info)->truelist = merge((yyvsp[-5].exp_info)->truelist, (yyvsp[-1].exp_info)->truelist); 
        (yyval.exp_info)->falselist = (yyvsp[-1].exp_info)->falselist; 
    }
#line 2685 "y.tab.c" /* yacc.c:1646  */
    break;

  case 60:
#line 861 "ass6_14CS30044.y" /* yacc.c:1646  */
    { //       1            2  3  4     5      6  7  8     9
        symtype t9 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        if(t9.btype == type_array)
        {
            string t = ST->gentemp(t9.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t9.base_t;
        }
        symtype t5 = ST->lookup((yyvsp[-4].exp_info)->loc)->type;
        if(t5.btype == type_array)
        {
            string t = ST->gentemp(t5.base_t);
            qar.emit(t,(yyvsp[-4].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-4].exp_info)->folder));
            (yyvsp[-4].exp_info)->loc = t; 
            (yyvsp[-4].exp_info)->btype = t5.base_t;
        }
        (yyval.exp_info) = new expression_type; 
        (yyval.exp_info)->loc = ST->gentemp(ST->lookup((yyvsp[-4].exp_info)->loc)->type.btype);
        qar.emit((yyval.exp_info)->loc,(yyvsp[0].exp_info)->loc,ASSIGN);
        list<int> I = makelist(qar.nextinstr);
        qar.emit("","",OP_GOTO,"");
        qar.backpatch((yyvsp[-3].exp_info)->nextlist,qar.nextinstr);
        qar.emit((yyval.exp_info)->loc,(yyvsp[-4].exp_info)->loc,ASSIGN);
        I = merge(I,makelist(qar.nextinstr));
        qar.emit("","",OP_GOTO,"");
        qar.backpatch((yyvsp[-7].exp_info)->nextlist, qar.nextinstr);
        qar.convInt2Bool((yyvsp[-8].exp_info));  
        qar.backpatch((yyvsp[-8].exp_info)->truelist,(yyvsp[-5].exp_info)->instr);
        qar.backpatch((yyvsp[-8].exp_info)->falselist,(yyvsp[-1].exp_info)->instr);
        qar.backpatch(I,qar.nextinstr);
    }
#line 2722 "y.tab.c" /* yacc.c:1646  */
    break;

  case 76:
#line 922 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type;
        (yyval.exp_info)->loc = ST->gentemp(); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,AND,(yyvsp[0].exp_info)->loc);
    }
#line 2748 "y.tab.c" /* yacc.c:1646  */
    break;

  case 78:
#line 948 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        int tempvar=692;
        double stard=45.67;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type;
        (yyval.exp_info)->loc = ST->gentemp(); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,XOR,(yyvsp[0].exp_info)->loc);
    }
#line 2776 "y.tab.c" /* yacc.c:1646  */
    break;

  case 80:
#line 975 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        int tempvar=90;
        double stard=34.56;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(tempvar,t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t;
        }
        symtype t1 = ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            string t = ST->gentemp(tempvar,t1.base_t);
            qar.emit(t,(yyvsp[-2].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[-2].exp_info)->folder));
            (yyvsp[-2].exp_info)->loc = t; 
            (yyvsp[-2].exp_info)->btype = t1.base_t;
        }
        (yyval.exp_info) = new expression_type;
        (yyval.exp_info)->loc = ST->gentemp(); 
        qar.emit((yyval.exp_info)->loc,(yyvsp[-2].exp_info)->loc,OR,(yyvsp[0].exp_info)->loc);
    }
#line 2804 "y.tab.c" /* yacc.c:1646  */
    break;

  case 82:
#line 1004 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        //cout<<"in Declarations"<<endl;
        basic_type type_now = (yyvsp[-2].btype);
        int temp_size = -1;
        if(type_now == type_char) temp_size = SIZE_CHAR;
        if(type_now == type_int)  temp_size = SIZE_INT;
        if(type_now == type_double)  temp_size = SIZE_DOUBLE;
        vector<decc*> lst = *((yyvsp[-1].ivec));
        for(vector<decc*>::iterator it = lst.begin(); it != lst.end(); it++)
        {
            decc *my_dec = *it;
            if(my_dec->btype == type_function)
            {
                ST = &(symtabvar);
                qar.emit(my_dec->name,"",FUNC_END,"");
            }            
            if(my_dec->btype == type_function)
            {
                symdata *var = ST->lookup(my_dec->name);
                double stard;
                symdata *retval = var->nested_symtab->lookup("retVal",type_now,my_dec->pc);               
                var->offset = ST->offset;
                var->size = 0;
                var->init_val = NULL;
                continue;
            }
            symdata *var = ST->lookup(my_dec->name,type_now);            
            var->nested_symtab = NULL;
            if(my_dec->alist == vector<int>() && my_dec->pc == 0) // id_name
            {
               // cout<<"line 1034"<<endl;
                var->type.btype = type_now;
                var->offset = ST->offset; 
                var->offset += temp_size;
                var->size = temp_size;
                if(my_dec->init_val != NULL)
                {
                    string rval = my_dec->init_val->loc;
                    qar.emit(var->name, rval,ASSIGN,"");
                    var->init_val = ST->lookup(rval)->init_val;
                }
                else
                    var->init_val = NULL;
            }
            else if(my_dec->alist!=vector<int>())   // seedha saadha array
            {
             //   cout<<"line 1050"<<endl;
                var->type.btype = type_array;
                var->type.base_t = type_now;
                var->type.alist = my_dec->alist;
                var->offset = ST->offset;
                double stard;
                int sz = temp_size; vector<int> tmp = var->type.alist; int tsz = tmp.size();
                for(int i = 0; i<tsz; i++) sz *= tmp[i];
                    ST->offset += sz;
                var->size = sz;
            }
            else if(my_dec->pc != 0)
            {
               // cout<<"line 1061"<<endl;
                var->type.btype = type_ptr;
                var->type.base_t = type_now;
                var->type.pc = my_dec->pc;
                var->offset = ST->offset; 
                temp_size = SIZE_PTR; // sizeof pointer
                ST->offset += temp_size;
                var->size = temp_size;
            }
        }  
    }
#line 2879 "y.tab.c" /* yacc.c:1646  */
    break;

  case 83:
#line 1077 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2885 "y.tab.c" /* yacc.c:1646  */
    break;

  case 84:
#line 1078 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2891 "y.tab.c" /* yacc.c:1646  */
    break;

  case 85:
#line 1079 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2897 "y.tab.c" /* yacc.c:1646  */
    break;

  case 86:
#line 1081 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        if(ST->lookup("retVal")->type.btype == type_void)
        {
            qar.emit("","",RETURN,"");
        }
        (yyval.exp_info) = new expression_type;
    }
#line 2909 "y.tab.c" /* yacc.c:1646  */
    break;

  case 87:
#line 1089 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        if(ST->lookup("retVal")->type.btype == ST->lookup((yyvsp[-1].exp_info)->loc)->type.btype)
        {
            qar.emit((yyvsp[-1].exp_info)->loc,"",RETURN,"");
        }
        (yyval.exp_info) = new expression_type;
    }
#line 2921 "y.tab.c" /* yacc.c:1646  */
    break;

  case 89:
#line 1102 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        symtype t3 = ST->lookup((yyvsp[0].exp_info)->loc)->type;
        int tempvar=45;
        double stard=57.12;
        if(t3.btype == type_array)
        {
            string t = ST->gentemp(tempvar,t3.base_t);
            qar.emit(t,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_FROM,*((yyvsp[0].exp_info)->folder));
            (yyvsp[0].exp_info)->loc = t; 
            (yyvsp[0].exp_info)->btype = t3.base_t; 
        }
        symtype t1 =  ST->lookup((yyvsp[-2].exp_info)->loc)->type;
        if(t1.btype == type_array)
        {
            qar.emit((yyvsp[-2].exp_info)->loc,(yyvsp[0].exp_info)->loc,ARRAY_INDEX_TO,*((yyvsp[-2].exp_info)->folder));
        }
        else
            qar.emit((yyvsp[-2].exp_info)->loc, (yyvsp[0].exp_info)->loc,ASSIGN,"");
        (yyval.exp_info) = (yyvsp[-2].exp_info);
    }
#line 2946 "y.tab.c" /* yacc.c:1646  */
    break;

  case 90:
#line 1125 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2952 "y.tab.c" /* yacc.c:1646  */
    break;

  case 91:
#line 1126 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2958 "y.tab.c" /* yacc.c:1646  */
    break;

  case 94:
#line 1129 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2964 "y.tab.c" /* yacc.c:1646  */
    break;

  case 95:
#line 1130 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2970 "y.tab.c" /* yacc.c:1646  */
    break;

  case 96:
#line 1131 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2976 "y.tab.c" /* yacc.c:1646  */
    break;

  case 97:
#line 1132 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 2982 "y.tab.c" /* yacc.c:1646  */
    break;

  case 98:
#line 1136 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.btype) = type_void;}
#line 2988 "y.tab.c" /* yacc.c:1646  */
    break;

  case 99:
#line 1137 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.btype) = type_char;}
#line 2994 "y.tab.c" /* yacc.c:1646  */
    break;

  case 100:
#line 1138 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3000 "y.tab.c" /* yacc.c:1646  */
    break;

  case 101:
#line 1139 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.btype) = type_int;}
#line 3006 "y.tab.c" /* yacc.c:1646  */
    break;

  case 102:
#line 1140 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3012 "y.tab.c" /* yacc.c:1646  */
    break;

  case 103:
#line 1141 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3018 "y.tab.c" /* yacc.c:1646  */
    break;

  case 104:
#line 1142 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.btype) = type_double;}
#line 3024 "y.tab.c" /* yacc.c:1646  */
    break;

  case 105:
#line 1143 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3030 "y.tab.c" /* yacc.c:1646  */
    break;

  case 106:
#line 1144 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3036 "y.tab.c" /* yacc.c:1646  */
    break;

  case 107:
#line 1145 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3042 "y.tab.c" /* yacc.c:1646  */
    break;

  case 108:
#line 1146 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3048 "y.tab.c" /* yacc.c:1646  */
    break;

  case 109:
#line 1147 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3054 "y.tab.c" /* yacc.c:1646  */
    break;

  case 110:
#line 1148 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3060 "y.tab.c" /* yacc.c:1646  */
    break;

  case 111:
#line 1149 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3066 "y.tab.c" /* yacc.c:1646  */
    break;

  case 130:
#line 1184 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.dec_info) = (yyvsp[0].dec_info); (yyval.dec_info)->pc = (yyvsp[-1].ival);}
#line 3072 "y.tab.c" /* yacc.c:1646  */
    break;

  case 131:
#line 1185 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.dec_info) = (yyvsp[0].dec_info); (yyval.dec_info)->pc = 0;}
#line 3078 "y.tab.c" /* yacc.c:1646  */
    break;

  case 132:
#line 1191 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        {(yyval.dec_info) = new decc; (yyval.dec_info)->name = *((yyvsp[0].str));}
        //cout<<"line 1187"<<endl;
    }
#line 3087 "y.tab.c" /* yacc.c:1646  */
    break;

  case 133:
#line 1195 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3093 "y.tab.c" /* yacc.c:1646  */
    break;

  case 136:
#line 1199 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        (yyval.dec_info) = (yyvsp[-4].dec_info); 
        int idx = ST->lookup((yyvsp[-1].exp_info)->loc)->init_val->ival;
        (yyval.dec_info)->alist.push_back(idx);
    }
#line 3103 "y.tab.c" /* yacc.c:1646  */
    break;

  case 138:
#line 1206 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
       // cout<<"line 1208"<<endl;
        (yyval.dec_info) = (yyvsp[-3].dec_info); //name of function
       // cout<<"line 1209"<<endl;
        (yyval.dec_info)->btype = type_function;
        double stard;
        symdata *fdata = ST->lookup((yyval.dec_info)->name,(yyval.dec_info)->btype);
        symtab *fsym = new symtab;
        fdata->nested_symtab = fsym;
        vector<param*> plist = *((yyvsp[-1].prm_list));
        for(int i = 0;i<plist.size(); i++)
        {
            param *my_prm = plist[i];
            fsym->lookup(my_prm->name,my_prm->type.btype);
        }
        //fsym->lookup("retVal",type_double);
        // set the new symbol table
        ST = fsym;
        qar.emit((yyval.dec_info)->name,"",FUNC_BEGIN,"");
    }
#line 3128 "y.tab.c" /* yacc.c:1646  */
    break;

  case 140:
#line 1235 "ass6_14CS30044.y" /* yacc.c:1646  */
    {   
        (yyval.ivec) = new vector<decc*>; 
        (yyval.ivec)->push_back((yyvsp[0].dec_info));
    }
#line 3137 "y.tab.c" /* yacc.c:1646  */
    break;

  case 141:
#line 1240 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        (yyvsp[-2].ivec)->push_back((yyvsp[0].dec_info)); 
        (yyval.ivec) = (yyvsp[-2].ivec);
    }
#line 3146 "y.tab.c" /* yacc.c:1646  */
    break;

  case 142:
#line 1249 "ass6_14CS30044.y" /* yacc.c:1646  */
    {   //cout<<"line 1237"<<endl;
        (yyval.dec_info) = (yyvsp[0].dec_info); (yyval.dec_info)->init_val = NULL;
    }
#line 3154 "y.tab.c" /* yacc.c:1646  */
    break;

  case 143:
#line 1252 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.dec_info) = (yyvsp[-2].dec_info); (yyval.dec_info)->init_val = (yyvsp[0].exp_info);}
#line 3160 "y.tab.c" /* yacc.c:1646  */
    break;

  case 149:
#line 1265 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        //cout<<"line 1252"<<endl;
    }
#line 3168 "y.tab.c" /* yacc.c:1646  */
    break;

  case 151:
#line 1271 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3174 "y.tab.c" /* yacc.c:1646  */
    break;

  case 152:
#line 1272 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3180 "y.tab.c" /* yacc.c:1646  */
    break;

  case 153:
#line 1276 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.ival) = 1;}
#line 3186 "y.tab.c" /* yacc.c:1646  */
    break;

  case 154:
#line 1277 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3192 "y.tab.c" /* yacc.c:1646  */
    break;

  case 155:
#line 1278 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.ival) = 1 + (yyvsp[0].ival);}
#line 3198 "y.tab.c" /* yacc.c:1646  */
    break;

  case 156:
#line 1279 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3204 "y.tab.c" /* yacc.c:1646  */
    break;

  case 160:
#line 1287 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.prm_list) = new vector<param*>;}
#line 3210 "y.tab.c" /* yacc.c:1646  */
    break;

  case 163:
#line 1296 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3216 "y.tab.c" /* yacc.c:1646  */
    break;

  case 165:
#line 1298 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3222 "y.tab.c" /* yacc.c:1646  */
    break;

  case 168:
#line 1308 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        //cout<<"line 1292"<<endl;
    }
#line 3230 "y.tab.c" /* yacc.c:1646  */
    break;

  case 172:
#line 1322 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3236 "y.tab.c" /* yacc.c:1646  */
    break;

  case 181:
#line 1337 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = (yyvsp[-1].exp_info);
    }
#line 3244 "y.tab.c" /* yacc.c:1646  */
    break;

  case 182:
#line 1340 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3250 "y.tab.c" /* yacc.c:1646  */
    break;

  case 183:
#line 1344 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.exp_info) = (yyvsp[0].exp_info); qar.backpatch((yyvsp[0].exp_info)->nextlist, qar.nextinstr);}
#line 3256 "y.tab.c" /* yacc.c:1646  */
    break;

  case 184:
#line 1346 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        (yyval.exp_info) = new expression_type;
        qar.backpatch((yyvsp[-2].exp_info)->nextlist, (yyvsp[-1].exp_info)->instr);
        (yyval.exp_info)->nextlist = (yyvsp[0].exp_info)->nextlist;
    }
#line 3266 "y.tab.c" /* yacc.c:1646  */
    break;

  case 185:
#line 1353 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.exp_info) = new expression_type;}
#line 3272 "y.tab.c" /* yacc.c:1646  */
    break;

  case 187:
#line 1357 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.exp_info) = new expression_type;}
#line 3278 "y.tab.c" /* yacc.c:1646  */
    break;

  case 190:
#line 1362 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.exp_info) = new expression_type;}
#line 3284 "y.tab.c" /* yacc.c:1646  */
    break;

  case 191:
#line 1366 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        int temp;
        qar.backpatch((yyvsp[-8].exp_info)->nextlist,qar.nextinstr);
        double stard;
        qar.convInt2Bool((yyvsp[-9].exp_info),temp);
        qar.backpatch((yyvsp[-9].exp_info)->truelist,(yyvsp[-6].exp_info)->instr);
        qar.backpatch((yyvsp[-9].exp_info)->falselist,(yyvsp[-2].exp_info)->instr);
        (yyval.exp_info) = new expression_type;
        (yyval.exp_info)->nextlist = merge((yyvsp[-5].exp_info)->nextlist,(yyvsp[-4].exp_info)->nextlist);        
        (yyval.exp_info)->nextlist = merge((yyval.exp_info)->nextlist,(yyvsp[-1].exp_info)->nextlist);   
        (yyval.exp_info)->nextlist = merge((yyval.exp_info)->nextlist,(yyvsp[0].exp_info)->nextlist);           
    }
#line 3301 "y.tab.c" /* yacc.c:1646  */
    break;

  case 192:
#line 1378 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3307 "y.tab.c" /* yacc.c:1646  */
    break;

  case 193:
#line 1380 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        int temp;
        qar.backpatch((yyvsp[-4].exp_info)->nextlist,qar.nextinstr);
        qar.convInt2Bool((yyvsp[-5].exp_info),temp);
        qar.backpatch((yyvsp[-5].exp_info)->truelist,(yyvsp[-2].exp_info)->instr);
        (yyval.exp_info) = new expression_type;
        (yyval.exp_info)->nextlist = merge((yyval.exp_info)->nextlist,(yyvsp[-5].exp_info)->falselist);   
        (yyval.exp_info)->nextlist = merge((yyvsp[-1].exp_info)->nextlist,(yyvsp[0].exp_info)->nextlist);   
    }
#line 3321 "y.tab.c" /* yacc.c:1646  */
    break;

  case 194:
#line 1393 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.prm_list) = new vector<param*>; (yyval.prm_list)->push_back((yyvsp[0].prm));}
#line 3327 "y.tab.c" /* yacc.c:1646  */
    break;

  case 195:
#line 1394 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyvsp[-2].prm_list)->push_back((yyvsp[0].prm)); (yyval.prm_list) = (yyvsp[-2].prm_list);}
#line 3333 "y.tab.c" /* yacc.c:1646  */
    break;

  case 196:
#line 1397 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.prm) = new param; (yyval.prm)->name = (yyvsp[0].dec_info)->name; (yyval.prm)->type.btype = (yyvsp[-1].btype);}
#line 3339 "y.tab.c" /* yacc.c:1646  */
    break;

  case 197:
#line 1398 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3345 "y.tab.c" /* yacc.c:1646  */
    break;

  case 198:
#line 1403 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        //cout<<"in IDENTIFIER"<<endl;
    }
#line 3353 "y.tab.c" /* yacc.c:1646  */
    break;

  case 199:
#line 1407 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        //cout<<"in identifier_list"<<endl;
    }
#line 3361 "y.tab.c" /* yacc.c:1646  */
    break;

  case 201:
#line 1417 "ass6_14CS30044.y" /* yacc.c:1646  */
    {(yyval.exp_info) = (yyvsp[0].exp_info);}
#line 3367 "y.tab.c" /* yacc.c:1646  */
    break;

  case 202:
#line 1418 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3373 "y.tab.c" /* yacc.c:1646  */
    break;

  case 203:
#line 1419 "ass6_14CS30044.y" /* yacc.c:1646  */
    {}
#line 3379 "y.tab.c" /* yacc.c:1646  */
    break;

  case 204:
#line 1424 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        int temp;
        qar.emit("","",OP_GOTO,"");
        qar.backpatch(makelist(qar.nextinstr-1),(yyvsp[-6].exp_info)->instr);  
        qar.backpatch((yyvsp[-3].exp_info)->nextlist,qar.nextinstr);
        qar.convInt2Bool((yyvsp[-4].exp_info),temp);
        qar.backpatch((yyvsp[-4].exp_info)->truelist,(yyvsp[-1].exp_info)->instr);
        qar.backpatch((yyvsp[0].exp_info)->nextlist,(yyvsp[-6].exp_info)->instr);    
        (yyval.exp_info) = new expression_type;
        (yyval.exp_info)->nextlist = (yyvsp[-4].exp_info)->falselist;        
    }
#line 3395 "y.tab.c" /* yacc.c:1646  */
    break;

  case 205:
#line 1436 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        int temp;
        qar.convInt2Bool((yyvsp[-2].exp_info),temp);
        qar.backpatch((yyvsp[-2].exp_info)->truelist,(yyvsp[-7].exp_info)->instr);
        qar.backpatch((yyvsp[-6].exp_info)->nextlist,(yyvsp[-5].exp_info)->instr);
        (yyval.exp_info) = new expression_type;
        (yyval.exp_info)->nextlist = (yyvsp[-2].exp_info)->falselist;
    }
#line 3408 "y.tab.c" /* yacc.c:1646  */
    break;

  case 206:
#line 1445 "ass6_14CS30044.y" /* yacc.c:1646  */
    {// 1   2       3         4  5      6         7  8  9    10          11 12 13    14   
        qar.emit("","",OP_GOTO,"");
        qar.backpatch(makelist(qar.nextinstr-1), (yyvsp[-5].exp_info)->instr );
        qar.backpatch((yyvsp[-7].exp_info)->nextlist,qar.nextinstr);
        int temp;
        qar.convInt2Bool((yyvsp[-8].exp_info),temp);
        qar.backpatch((yyvsp[-8].exp_info)->truelist,(yyvsp[-1].exp_info)->instr);
        qar.backpatch((yyvsp[0].exp_info)->nextlist,(yyvsp[-5].exp_info)->instr);
        qar.backpatch((yyvsp[-3].exp_info)->nextlist,(yyvsp[-9].exp_info)->instr);
        (yyval.exp_info) = new expression_type;
        (yyval.exp_info)->nextlist = (yyvsp[-8].exp_info)->falselist;
    }
#line 3425 "y.tab.c" /* yacc.c:1646  */
    break;

  case 212:
#line 1472 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        ST = &(symtabvar);
        qar.emit((yyvsp[-1].dec_info)->name,"",FUNC_END,"");
    }
#line 3434 "y.tab.c" /* yacc.c:1646  */
    break;

  case 213:
#line 1481 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        //cout<<"in Declarations line 1462"<<endl;
    }
#line 3442 "y.tab.c" /* yacc.c:1646  */
    break;

  case 214:
#line 1485 "ass6_14CS30044.y" /* yacc.c:1646  */
    {
        //cout<<"in declaration_list"<<endl;
    }
#line 3450 "y.tab.c" /* yacc.c:1646  */
    break;


#line 3454 "y.tab.c" /* yacc.c:1646  */
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYTERROR;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined yyoverflow || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  return yyresult;
}
#line 1490 "ass6_14CS30044.y" /* yacc.c:1906  */

void yyerror(string s) {
    cout << s << endl;
}
int main(int argc, char* argv[])
{
    if(argc<1 || argc > 2)
    {
        cout<<" To run: tinyc < <filename> <executable_name> "<<endl;
        return 0;
    }
    yydebug = 0;
    //cout<<"i am here"<<endl;
    bool failure = yyparse();  
    //cout<<"B"<<endl;
    int sz = qar.array.size();
    //cout<<"C"<<endl;
    int i=0;
    while(i<sz){
        if(qar.array[i].op == OP_GOTO && qar.array[i].result == "")
        {
            stringstream ss;
            ss<<i+1;
            qar.array[i].result = ss.str();
        }
        cout<<i<<": "; 
        qar.array[i].print();i++;
    }    
    cout<<"SYMBOL TABLE"<<endl;
    ST->print();
    cout<<""<<endl;
    map<string,symdata*> :: iterator it = ST->_symtab.begin();
    while(it != ST->_symtab.end()){
        symdata *tmp = it->second;
        if(tmp->nested_symtab != NULL)
        {
            cout<<"SYMBOL TABLE("<<tmp->name<<")"<<endl;
            tmp->nested_symtab->print();
            cout<<""<<endl;
        }
        it++;
    }    
    string outfile = "a.out";
    if(argc==2) outfile = string(argv[1]);
    string tmp = outfile + ".s";
    ofstream outf(tmp.c_str());
    streambuf *coutbuf = cout.rdbuf();
    cout.rdbuf(outf.rdbuf());
    ST = &symtabvar;
    gencode();
    cout.rdbuf(coutbuf);
    if(!failure)
        printf("SUCCESSFULLY PARSED :)\n");
    else
        printf("PARSING FAILED !!\n");          
    string command = "gcc " + tmp + " -L. -lmyl -o " + outfile;
    system(command.c_str());
    return 0;
}

