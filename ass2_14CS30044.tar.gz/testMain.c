#include "myl.h"

int main(){
	// Test Cases for prints function
	prints("Test cases for prints function:");
	// With some escape sequences 
	prints("\nCharacters::\b ");
	prints("A....Z, a...z, 0....9, special symbols\n");
	prints("\tTerminated by '\\0'\0Cannot be printed");

	// Test Cases for printi function
	int c;
	prints("\n\nTest Cases for printi function:");
	prints("\nParam\tOutput\t#Characters printed");
	prints("\n123\t");
	c =printi(123);
	prints("\t");
	printi(c);

	prints("\n-123\t");
	c =printi(-123);
	prints("\t");
	printi(c);

	prints("\n000\t");
	c =printi(000);
	prints("\t");
	printi(c);

	prints("\n2147483647(max)\t");
	c =printi(2147483647);
	prints("\t");
	printi(c);

	prints("\n-2147483648(min)\t");
	c =printi(-2147483648);
	prints("\t");
	printi(c);

	// Test Cases for printd function
	prints("\n\nTest Cases for printd function: (float- 6 decimal digits after radix point)");
	prints("\nParameter\tOutput\t#Characters printed");
	prints("\n123.00\t");
	c =printd(123.00);
	prints("\t");
	printi(c);

	prints("\n-123.23455123\t");
	c =printd(-123.23455123);
	prints("\t");
	printi(c);

	prints("\n000.0\t");
	c =printd(000.0);
	prints("\t");
	printi(c);

	prints("\n823458648\t");
	c =printd(823458648);
	prints("\t");
	printi(c);

	prints("\n-00.0005677\t");
	c =printd(-00.0005677);
	prints("\t");
	printi(c);

	prints("\n1.2e+32\t");
	c =printd(1.2e+32);
	prints("\t");
	printi(c);

	prints("\n3.4e+38(max)\t");
	c =printd(3.4e+38);
	prints("\t");
	printi(c);

	prints("\n-3.4e+38(min)\t");
	c =printd(-3.4e+38);
	prints("\t");
	printi(c);

	prints("\n-1234567895646346.990768543669862392424e-10\t");
	c =printd(-1234567895646346.990768543669862392424e-10);
	prints("\t");
	printi(c);

	//Test case for readi function
	prints("\n\nTest case for readi function:");
	prints("\nEnter an integer: ");
	int num, *ep,err;
	ep=&err;
	num = readi(ep);
	if(err==OK){
		int di=printi(num);
		prints("\nNo. of characters: ");
		printi(di);
		prints("\n");
	}
	else if(err==ERR)
		prints("Erroneous integer input.\n");

	//Test case for readf function
	prints("\n\nTest case for readf function:");
	prints("\nEnter a floating point number: ");
	float fnum, *fp;
	fp = &fnum;
	int errf=readf(fp);
	if(errf)
		prints("Erroneous float input.\n");
	else{
			int nf =printd(fnum);
			prints("\nNo. of characters: ");
			printi(nf);
			prints("\n");
	}
return 0;
}
