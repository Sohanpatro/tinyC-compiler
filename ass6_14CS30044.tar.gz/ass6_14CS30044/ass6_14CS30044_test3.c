int printi(int num);
int prints(char * c);
int readi(int *eP);


int fibo(int n)
{
    if(n == 0) return 0;
    else if(n==1) return 1;
    else return fibo(n-1) + fibo(n-2);
}

int main()
{
    prints("Lets compute the fibonacci series!!\n Enter a number(<=45): ");
    int a, c, *err;
    err= &c;
    a = readi(&err);
    int small=0,large=1,i=1,temp;
    for(i=1;i<a+1;i++)
    {
        temp=large;
        large=small+large;
        small=temp;
        printi(large);
        prints(" ");
    }
    prints("\n");
    return 0;
}
