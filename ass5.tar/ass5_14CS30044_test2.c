// Test Declaration
int tst = 2;
double d = 223.33;
int i, w[10];
int a = 4, *p, b;
void func(int i, double d);
char c;

int main () {
	double e = 21.3;
	int f, w[3];
	char c1;
	int r1w = 42, *q, y;
}
