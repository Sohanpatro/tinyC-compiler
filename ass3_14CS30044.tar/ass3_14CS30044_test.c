/*
Checking for
	working of 
		Multi-line comments : TO BE IGNORED
*/

//Test starts : TO BE IGNORED :)

#include <stdio.h>
int main(){
// Keywords testing
"Keywords"
auto enum restrict unsigned
break extern return void
case float short volatile
char for signed while
const goto sizeof _Bool
continue if static _Complex
default inline struct _Imaginary
do int switch
double long typedef
else register union

//Identifiers
"Identifiers"
asdf_
 _ 
_asd
_12we23
sd_2d
as0212

//Non-Identifiers
"Non-Identifiers"
12ww_
// Constants
"Constants"

// Integers
"Integers"
12
12340
0

// Non- integers
"Non- integers"
0123

// Floating constants
"Floating constants"
.023
123.0342
213.
000.
000.e-0987654
23E+123
21.23e0123

// Non- Floating constants
"Non- Floating constants"
-12.332
e32

//Character constants
"Character constants"
'as - df'
'a'
'\a'
'"'

// Non-Character constants
"Non-Character constants"
''
'\'

//String Literals
"String Literals"
"123423\b"
""

//Non-String Literals
"Non-String Literals"
"sdf\erfg"
"\"
"""

// Punctuators
"Punctuators"
[ ] ( ) { } . ->
++ -- & * + - ~ !
/ % << >> < > <= >= == != ^ | && ||
? : ; ...
= *= /= %= += -= <<= >>= &= ^= |=
, #

"Some Valid programming statements"
	// Testing the tokenization with some valid programming statements

	int x;
	float y=12.3;
	x=32;
	float z=(x+y-12.3e-2)/23;
	char c = 'a';
	str="qwerty";

	i++;
	arr[2] = b[12.3];

	if(j==0||tst>=3&&try<234)
	{	*pt->iVal=12.21; }

	const int *cpt = getInt(a,b);

    while(tmp-->0){
    	for(a=b; c != d; e++){
		scanf("%d %d",&x,&y);
		}
    }

	a+=b%10;
	c &=d-e;


    return 0;	
}
