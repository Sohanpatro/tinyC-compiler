#define BUFF 100
#define ERR 1
#define OK 0

//My myl.c: Library functions
//===========

int prints(char * str){
	int i;
	for(i=0; str[i]!='\0'; i++){
	__asm__ __volatile__ (
			"movl $1, %%eax \n\t"
			"movq $1, %%rdi \n\t"
			"syscall \n\t"
			:
			:"S"(str+i), "d"(1)
			) ;
	}
	return i;
}

int printi(int numm) {
long n=numm;
char buff[BUFF], zero='0';
int i=0, j, k, bytes;
if(n == 0) buff[i++]=zero;
else{
if(n < 0) {
buff[i++]='-';
n = -n;
}
while(n){
int dig = n%10;
buff[i++] = (char)(zero+dig);
n /= 10;
}if(buff[0] == '-') j = 1;
else j = 0;
k=i-1;
while(j<k){
char temp=buff[j];
buff[j++] = buff[k];
buff[k--] = temp;
}
}
bytes = i;
__asm__ __volatile__ (
"movl $1, %%eax \n\t"
"movq $1, %%rdi \n\t"
"syscall \n\t"
:
:"S"(buff), "d"(bytes)
) ; // $4: write, $1: on stdin
return i;
}

int readi(int *eP){
	char buff[BUFF]="", zero='0';
	int n=0;
	long num=0;
	while(1)
	{
		__asm__ __volatile__ ("syscall \n\t"::"a"(0), "D"(0), "S"(buff+n), "d"(1));
		
		if(buff[n]==' '||buff[n]=='\n'||buff[n]=='\t'||buff[n]=='\0')  {
				if (n==0) continue;
				else break;
			}
		++n;
	}
	int i=0, neg=0;
	if('-'==buff[0]){
		neg=1; i++;
	}
	else if('+'==buff[0])
		i++;
	while(i<n){
		if(!(buff[i]>='0' && buff[i]<='9')){
			*eP = ERR; return -1;
			}
		else{
			num = num*10+(buff[i]-zero);
		}
		i++;
	}
	if(neg) num*=-1;
	int up= sizeof(int)*8 - 1;
	long max=1, min=1;
	while(up){
		max*=2;
		up--;
	}
	max--;
	min = -1*max -1;
	if(num > max || num < min){
		*eP = ERR; return -1;
	}
	else{
		*eP = OK;
		return (int)num;
	}
}

int readf(float *fp){
	char buff[BUFF]="", zero='0';
	int n=0, ef=0, exp=0;//ef- exp part is there, fr=0;	//d-0 => no fractional part
	int neg=0, negexp=0;
	double num=0.0, fr=0, frac=1;
	while(1)
	{
		__asm__ __volatile__ ("syscall \n\t"::"a"(0), "D"(0), "S"(buff+n), "d"(1));
		
		if(buff[n]==' '||buff[n]=='\n'||buff[n]=='\t'||buff[n]=='\0')
			{ if (n==0) continue; else break; }
		++n;
	}
	int i=0;
	if('-'==buff[0]){
		neg=1; i++;
	}
	else if('+'==buff[0])
		i++;
	while(i<n){
		if(buff[i]>='0' && buff[i]<='9'){
			if(0==fr)
				num = num*10+(buff[i]-zero);
			else{
				frac /=10.0;
				num+= (buff[i]-zero)*frac;
			}
			 
		}
		else if('.'==buff[i]){
			if(fr){return ERR;}
			fr=1;
		}
		else if('e'==buff[i] || 'E'==buff[i]){
			ef=1;
			break;
		}
		else{
			return ERR;
		}
		i++;
	}
	
	
	if(ef){
			i++;
		if('-'==buff[i]){
			negexp=1; i++;
		}
		else if('+'==buff[i])
			i++;
		if(i==n){			//1.2e or 12e- or 2.3e+
			return ERR;
		}
		while(i<n){
			if(!(buff[i]>='0' && buff[i]<='9')){
				 return ERR;
				}
			else{
				exp = exp*10+(buff[i]-zero);
			}
			i++;
		}
	}
	
	if(negexp){
		while(exp){
			num/=10;
			exp--;
		}
	}
	else{
		while(exp){
			num*=10;
			exp--;
		}
	}
	if(neg) num*=-1;
	if(num>3.4e38 ||num<-3.4e38){
		return ERR;
	}
	int r;
	if((long long int)(num*10000000)%10 == 5){
		if(((long long int)(num*1000000)%10)%2==1)
			r=1;
		else
			r=0;
	}
	else if((long long int)(num*10000000)%10 > 5)
		r=1;
	else
		r=0;
	float tmpfnum = (float)num;
	if(r) tmpfnum+=.000001;
	*fp = tmpfnum;
	return OK;
	
}

int printd(float f){
	int c=(f<0)? 1:0;
	if(c) prints("-");
	long double fabs = c? -f : f;
	int d=0, flag=0 ;	//d- position of decimal point
	
	int r;
	if((long long int)(fabs*10000000)%10 == 5){
		if(((long long int)(fabs*1000000)%10)%2==1)
			r=1;
		else
			r=0;
	}
	else if((long long int)(fabs*10000000)%10 > 5)
		r=1;
	else
		r=0;
	if (r) fabs+=.000001;
	if(0==(int)fabs) {
		printi(0);
		flag=1;
	} else{
		while(fabs >= 1){
			fabs/=10;
			d++;
		}
	}
	for(int i=1; i <= d; i++){
		fabs*=10;
		int tmi=(int)fabs;
		if(fabs-tmi>.99999999) tmi++;
		printi(tmi);
		fabs-=tmi;
	}
	prints(".");
	for(int i=0; i < 6; i++){
		fabs*=10;
		printi(((long int)fabs)%10);
	}
	if(c) d++;	//one more character for '-'
	if(flag) {
		 if(c) return 9;
 		else return 8;
	}
	else return d+7;
}

