/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    SIZEOF_KEYWORD = 258,
    POINTER_OP = 259,
    INCREMENT_OP = 260,
    DECREMENT_OP = 261,
    LEFT_SHIFT_OP = 262,
    RIGHT_SHIFT_OP = 263,
    LESS_EQUAL_OP = 264,
    GREATER_EQUAL_OP = 265,
    EQUAL_OP = 266,
    NOT_EQUAL_OP = 267,
    LOGICAL_AND_OP = 268,
    LOGICAL_OR_OP = 269,
    MUL_ASSIGN = 270,
    DIV_ASSIGN = 271,
    MOD_ASSIGN = 272,
    ADD_ASSIGN = 273,
    SUB_ASSIGN = 274,
    LEFT_SHIFT_ASSIGN = 275,
    RIGHT_SHIFT_ASSIGN = 276,
    AND_ASSIGN = 277,
    XOR_ASSIGN = 278,
    OR_ASSIGN = 279,
    TYPE_NAME = 280,
    TYPEDEF_KEYWORD = 281,
    EXTERN_KEYWORD = 282,
    STATIC_KEYWORD = 283,
    AUTO_KEYWORD = 284,
    REGISTER_KEYWORD = 285,
    CHAR_KEYWORD = 286,
    SHORT_KEYWORD = 287,
    INT_KEYWORD = 288,
    LONG_KEYWORD = 289,
    SIGNED_KEYWORD = 290,
    UNSIGNED_KEYWORD = 291,
    FLOAT_KEYWORD = 292,
    DOUBLE_KEYWORD = 293,
    CONST_KEYWORD = 294,
    RESTRICT_KEYWORD = 295,
    VOLATILE_KEYWORD = 296,
    VOID_KEYWORD = 297,
    BOOL_KEYWORD = 298,
    COMPLEX_KEYWORD = 299,
    IMAGINARY_KEYWORD = 300,
    INLINE_KEYWORD = 301,
    STRUCT_KEYWORD = 302,
    UNION_KEYWORD = 303,
    ENUM_KEYWORD = 304,
    ELLIPSIS = 305,
    CASE_KEYWORD = 306,
    DEFAULT_KEYWORD = 307,
    IF_KEYWORD = 308,
    ELSE_KEYWORD = 309,
    SWITCH_KEYWORD = 310,
    WHILE_KEYWORD = 311,
    DO_KEYWORD = 312,
    FOR_KEYWORD = 313,
    GOTO_KEYWORD = 314,
    CONTINUE_KEYWORD = 315,
    BREAK_KEYWORD = 316,
    RETURN_KEYWORD = 317,
    STRING_LITERAL = 318,
    IDENTIFIER = 319,
    INTEGER_CONSTANT = 320,
    FLOAT_CONSTANT = 321,
    CHAR_CONSTANT = 322
  };
#endif
/* Tokens.  */
#define SIZEOF_KEYWORD 258
#define POINTER_OP 259
#define INCREMENT_OP 260
#define DECREMENT_OP 261
#define LEFT_SHIFT_OP 262
#define RIGHT_SHIFT_OP 263
#define LESS_EQUAL_OP 264
#define GREATER_EQUAL_OP 265
#define EQUAL_OP 266
#define NOT_EQUAL_OP 267
#define LOGICAL_AND_OP 268
#define LOGICAL_OR_OP 269
#define MUL_ASSIGN 270
#define DIV_ASSIGN 271
#define MOD_ASSIGN 272
#define ADD_ASSIGN 273
#define SUB_ASSIGN 274
#define LEFT_SHIFT_ASSIGN 275
#define RIGHT_SHIFT_ASSIGN 276
#define AND_ASSIGN 277
#define XOR_ASSIGN 278
#define OR_ASSIGN 279
#define TYPE_NAME 280
#define TYPEDEF_KEYWORD 281
#define EXTERN_KEYWORD 282
#define STATIC_KEYWORD 283
#define AUTO_KEYWORD 284
#define REGISTER_KEYWORD 285
#define CHAR_KEYWORD 286
#define SHORT_KEYWORD 287
#define INT_KEYWORD 288
#define LONG_KEYWORD 289
#define SIGNED_KEYWORD 290
#define UNSIGNED_KEYWORD 291
#define FLOAT_KEYWORD 292
#define DOUBLE_KEYWORD 293
#define CONST_KEYWORD 294
#define RESTRICT_KEYWORD 295
#define VOLATILE_KEYWORD 296
#define VOID_KEYWORD 297
#define BOOL_KEYWORD 298
#define COMPLEX_KEYWORD 299
#define IMAGINARY_KEYWORD 300
#define INLINE_KEYWORD 301
#define STRUCT_KEYWORD 302
#define UNION_KEYWORD 303
#define ENUM_KEYWORD 304
#define ELLIPSIS 305
#define CASE_KEYWORD 306
#define DEFAULT_KEYWORD 307
#define IF_KEYWORD 308
#define ELSE_KEYWORD 309
#define SWITCH_KEYWORD 310
#define WHILE_KEYWORD 311
#define DO_KEYWORD 312
#define FOR_KEYWORD 313
#define GOTO_KEYWORD 314
#define CONTINUE_KEYWORD 315
#define BREAK_KEYWORD 316
#define RETURN_KEYWORD 317
#define STRING_LITERAL 318
#define IDENTIFIER 319
#define INTEGER_CONSTANT 320
#define FLOAT_CONSTANT 321
#define CHAR_CONSTANT 322

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 20 "ass6_14CS30044.y" /* yacc.c:1909  */

    opcode op;                     // to store opcode of non terminal
    int ival;                       // to store integer value
    string *str;                    // pointer to a string
    double dval;                    // to store double value
    void* ptr;                      // to store pointer value
    symtype *typeinfo;              // keeps info of all the types
    vector<param*> *prm_list;       // holds a list of parameters
    symdata *symdat;                // a pointer to an entry in the symbol table
    basic_type btype;              // a basic type enum
    decc *dec_info;                 // holds info on declartors
    char cval;                      // to store the char vaue
    vector<decc*> *ivec;            // holds a list of declators
    param *prm;                     // holds parameters like name and type of a parameter
    expression_type *exp_info;                 // holds info like loc and type for an expression and truelist false list and next list for statements

#line 205 "y.tab.h" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
