
#ifndef Translator
#define Translator
#include <bits/stdc++.h>
#include<iostream>
#include<vector>
#include <algorithm>
#define char_size 1
#define int_size 4
#define double_size 8
#define pointer_size 4
extern char* yytext;
extern int yyparse();

using namespace std;

//
/** Forward Class Declarations (Class is used instead of struct) */
class symtab;		// for entire symbol table
class sym;			// for each entry (row) in a symbol table
class symType;		// for the type of a symbol in the symbol table
class quads;		// for all the entire quads
class quad;			// for each entry in each quad array

					/** types of all enums (grouping) */
enum etype			// enumeration of types
{
	VOID, CHAR, INT, DOUBLE, PTR, ARR, FUNC
};

enum optype
{
	EQUAL,		//equality operator
	LT, GT, LE, GE, EQOP, NEOP,		// relational operators
	GOTO, RETURN,			// for jump operations
	ADD, SUB, MULT, DIVIDE, RIGHTOP, LEFTOP, MODOP,	// for alu operations
	UMINUS, UPLUS, ADDRESS, RIGHT_POINTER, BNOT, LNOT,	// unary operators
	BAND, XOR, INOR,			// logical operators
	PTRL, PTRR,		//PTR Assign
	ARRR, ARRL,			// for arrays
	PARAM, CALL, LABEL	//for function calling
};

/** Class Declarations */
class symType {		// for type of an entry of symbol table
public:
	etype cat;		// for its category
	symType* ptr;
	int width;		// for the size of the array

	symType(etype cat, symType* ptr = NULL, int width = 1);	//Constructor
	friend ostream& operator << (ostream&, const symType);
};

class sym {			// for each entry (row / element) of symbol table
public:
	string name;		//Name of element of symbol table
	symType* type;		//ptr to type of element of symbol table
	string init;		// for element / symbol initialisation
	string category;	// for categorisation into global, local and temporary
	int size;			// size of element of symbol table
	int offset;			// offset of element of symbol table
	symtab* nest;		// ptr to nested symbol table

	sym(string s, etype t = INT, symType* ptr = NULL, int width = 0);		// Constructor
	sym* initialize (string s);			// for initialisation of ST
	
	sym* update(etype t);	// to update using nested ST ptr and raw type
	sym* update(symType * sym);	// to update using nested ST ptr and type object

	friend ostream& operator << (ostream&, const sym*);
	sym* linkst(symtab* t);	// to link back to the <parent> ST 't'
};

class symtab {			//for a symbol table (ST)
public:
	string tname;		// table name
	int tcount;			// count var for temporary vars
	list <sym> table;	// to list the table of symbols
	symtab* parent;		// ptr to the parent ST

	symtab(string name = "");		// Constructor
	sym* lookup(string name);		// look up in the ST
	void print(int all = 0);			// Print the ST (depending on the parameter)
	void computeOffsets();			// to compute the offsets of each entry of the ST at the end (recursively)
};

class quad {		// for individual quads
public:
	optype op;		//operator type
	string arg1;	// for argument 1
	string arg2;	// for argument 2
	string result;	// for result

	// Constructors
	quad(string result, string arg1, optype op = EQUAL, string arg2 = "");
	quad(string result, int arg1, optype op = EQUAL, string arg2 = "");

	void print();	// to print the quads
	void update(int address);	// to backpatch address

};

class quads {
public:
	vector <quad> array;	// for Vector of quads

	quads() {
		array.reserve(300);		// initially reserving for quads
	}

	void print();		// to print all quads
	void printtab();	// to print quads in tabular form as asked in question
};

class GlobalST {		// for the unique global ST object
public:
	static GlobalST* getInstance();		// has a single unique instance of GST

private:
	GlobalST();		// constructor
	static GlobalST* pGlobalST;	// ptr to the GlobalST instance
};

/** Function Declarations (required for the semantic actions)*/
sym* gentemp(etype t = INT, string init = "");		// Generate a temporary variable and insert it in symbol table
sym* gentemp(symType* t, string init = "");		// Generate a temporary variable and insert it in symbol table

void backpatch(list <int> l, int i);
void emit(optype opL, string res, string a1 = "", string a2 = "");	// string operands
void emit(optype op, string res, int a1, string a2="");			// one int operand
	
typedef list<int> lint;		// Convenience

list<int> makelist(int);	// making a new list
list<int> merge(list <int> & l1, list <int> & l2);	// merging the lists

int sizeOfType(symType*);							// to calculate size of any type
string conv2string(const symType*);			// to printe the type structure

string op2str(int);								// to Convert an op to string

sym* conv(sym*, etype);							// Convert symbol to different type
bool typecheck(sym* &s1, sym* &s2);					// Checks if two symbol table entries have same type
bool typecheck(symType* s1, symType* s2);			// Checks if the type objects are equivalent

int nextinstr();									// to Return the address of the next instruction
string number2string(int);							// to Convert a number to string (mainly used to store numbers)

void changeTable(symtab* newtable);			// to change the current symbol table


/** Some global vars used in the translator.cxx file */
extern symtab* table;		// Current ST
extern symtab* gTable;		// global ST
extern quads qarr;			// for the array / list of Quads
extern sym* currsym;		// ptr to the current symbol


/** Some structs for the Attributes / Global for Boolean Expression***/
struct expr {
	bool isbool;				// to check if the expression is boolean type
								
	// Valid for non-bool type
	sym* symp;					// Pointer to the entry of the ST
								
	// Valid for bool type only
	lint truelist;				// Truelist - for boolean expressions
	lint falselist;				// Falselist - for boolean expressions

	lint nextlist;				// Valid for statement expression
};

struct statement {
	lint nextlist;				// Nextlist for statement
};

struct unary {
	etype cat;					// for category
	sym* loc;					// Temporary var used for computing array address
	sym* symp;					// Pointer to symbol table
	symType* type;				// type of the subarray generated
};

// Utility functions
// template function is used as any (multiple) types can be converted to string
template <typename T> string tostr(const T& t) {	// to convert any type to string type
	ostringstream os;
	os << t;
	return os.str();
}

expr* conv2bool(expr*);				// convert any expression to bool
expr* convfrombool(expr*);			// convert bool to expression


#endif
