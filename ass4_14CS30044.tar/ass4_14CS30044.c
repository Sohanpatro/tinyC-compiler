#include <stdio.h>
#include "y.tab.h"
extern int yyparse();
extern char* yytext;
//extern int yyval;
int main(){
	yyparse();
	return 0;
}
