#include <stdio.h>
#include "y.tab.h"
extern char* yytext;
//extern int yyval;
int main(){
	int token;
	while(token=yylex()){
		if(token<=_Imaginary_KEYWORD)printf("< KEYWORD, %d, %s >\n",token,yytext);
		else if(token==SINGLE_LINE_COMMENT)printf("< SINGLE LINE COMMENT, %d >\n",token);
		else if(token==MULTI_LINE_COMMENT)printf("< MULTI LINE COMMENT, %d >\n",token);
		else if(token==IDENTIFIER)printf("< IDENTIFIER, %d, %s >\n",token,yytext);
		else if(token==INTEGER_CONST)printf("< INTEGER, %d, %d >\n",token,yylval.intVal);
		else if(token==FLOATING_CONST)printf("< FLOAT, %d, %s >\n",token,yytext);
		else if(token==CHARACTER_CONST)printf("< CHARACTER, %d, %s >\n",token,yytext);
		else if(token==STRING_LITERAL)printf("< STRING LITERAL, %d, %s >\n",token,yytext);
		else if(token==LEFT_SQUARE_BRACKET)printf("< LEFT SQUARE BRACKET, %d, %s >\n",token,yytext);
		else if(token==RIGHT_SQUARE_BRACKET)printf("< RIGHT SQUARE BRACKET, %d, %s >\n",token,yytext);
		else if(token==LEFT_ROUND_BRACKET)printf("< LEFT ROUND BRACKET, %d, %s >\n",token,yytext);
		else if(token==RIGHT_ROUND_BRACKET)printf("< RIGHT ROUND BRACKET, %d, %s >\n",token,yytext);
		else if(token==LEFT_CURLY_BRACKET)printf("< LEFT CURLY BRACKET, %d, %s >\n",token,yytext);
		else if(token==RIGHT_CURLY_BRACKET)printf("< RIGHT CURLY BRACKET, %d, %s >\n",token,yytext);
		else if(token==DOT)printf("< DOT, %d, %s >\n",token,yytext);
		else if(token==ARROW)printf("< ARROW, %d, %s >\n",token,yytext);
		else if(token==INCREMENT)printf("< INCREMENT, %d, %s >\n",token,yytext);
		else if(token==DECREMENT)printf("< DECREMENT, %d, %s >\n",token,yytext);
		else if(token==AND)printf("< AMPERSAND(AND), %d, %s >\n",token,yytext);
		else if(token==ASTERISK)printf("< ASTERISK, %d, %s >\n",token,yytext);
		else if(token==PLUS)printf("< PLUS, %d, %s >\n",token,yytext);
		else if(token==MINUS)printf("< MINUS, %d, %s >\n",token,yytext);
		else if(token==TILDA)printf("< TILDA, %d, %s >\n",token,yytext);
		else if(token==NOT)printf("< NEGATION(NOT), %d, %s >\n",token,yytext);
		else if(token==FORWARD_SLASH)printf("< FORWARD SLASH, %d, %s >\n",token,yytext);
		else if(token==PERCENT)printf("< PERCENT, %d, %s >\n",token,yytext);
		else if(token==LEFT_SHIFT)printf("< LEFT SHIFT, %d, %s >\n",token,yytext);
		else if(token==RIGHT_SHIFT)printf("< RIGHT SHIFT, %d, %s >\n",token,yytext);
		else if(token==LESS_THAN)printf("< LESS THAN, %d, %s >\n",token,yytext);
		else if(token==GREATER_THAN)printf("< GREATER THAN, %d, %s >\n",token,yytext);
		else if(token==LESS_THAN_EQUAL_T0)printf("< LESS THAN EQUAL T0, %d, %s >\n",token,yytext);
		else if(token==GREATER_THAN_EQUAL_TO)printf("< GREATER THAN EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==DOUBLE_EQUAL_TO)printf("< DOUBLE EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==NOT_EQUAL_TO)printf("< NOT EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==XOR)printf("< XOR, %d, %s >\n",token,yytext);
		else if(token==OR)printf("< OR, %d, %s >\n",token,yytext);
		else if(token==LOGICAL_AND)printf("< LOGICAL AND, %d, %s >\n",token,yytext);
		else if(token==LOGICAL_OR)printf("< LOGICAL OR, %d, %s >\n",token,yytext);
		else if(token==QUESTION_MARK)printf("< QUESTION MARK, %d, %s >\n",token,yytext);
		else if(token==COLON)printf("< COLON, %d, %s >\n",token,yytext);
		else if(token==SEMI_COLON)printf("< SEMI COLON, %d, %s >\n",token,yytext);
		else if(token==ELLIPSIS)printf("< ELLIPSIS, %d, %s >\n",token,yytext);
		else if(token==EQUAL_TO)printf("< EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==ASTERISK_EQUAL_TO)printf("< ASTERISK EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==SLASH_EQUAL_TO)printf("< SLASH EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==PERCENT_EQUAL_TO)printf("< PERCENT EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==PLUS_EQUAL_TO)printf("< PLUS EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==MINUS_EQUAL_TO)printf("< MINUS EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==LEFT_SHIFT_EQUAL_TO)printf("< LEFT SHIFT EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==RIGHT_SHIFT_EQUAL_TO)printf("< RIGHT SHIFT EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==AND_EQUAL_TO)printf("< AND EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==XOR_EQUAL_TO)printf("< XOR EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==OR_EQUAL_TO)printf("< OR EQUAL TO, %d, %s >\n",token,yytext);
		else if(token==COMMA)printf("< COMMA, %d, %s >\n",token,yytext);
		else if(token==HASH)printf("< HASH, %d, %s >\n",token,yytext);
	}

	return 0;
}

