
int printi(int num);
int prints(char * c);
int readi(int *eP);

int func(int i)
{
	return i*i;
}
int fact(int i)
{
	if(i==1)
	{
		return 1;
	}
	else
	{
		int ret=1,t=1;
		for(t=1;t<i+1;t++)
		{
			ret=ret*t;
		}
		return ret;
	}
}
int main()
{
    int a[10], arel;
    a[0] = 20;
    arel = a[0] + 30;
    a[0] = arel;
    a[1] = a[0];
    //arel=a[0]+a[1];
    printi(a[1]);
    int i=0,x=1;
    int t=1,ans=1;
    for(i=1;i<10;i++)
    {
    	x=x*i;
    }
    int *ep;
    prints("Enter an integer to find its square: ");
    prints("\nCaution: if the square of the integer exceeds the maximum value of int, you may get an Invalid output!\n");
    i=readi(&ep);
    i=func(i);
	a[1]=100;
    printi(i);
    prints("\n");
    prints("Enter an integer(<=14) to calculate its factorial: ");
    i=readi(&ep);
    prints("The read integer is: ");
    printi(i);
    prints(" \nIts factorial is: ");
   	t=fact(i);
    printi(t);
    prints("\n");
}
