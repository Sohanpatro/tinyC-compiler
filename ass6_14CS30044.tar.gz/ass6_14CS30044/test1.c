
#include "myl.h"
int main()
{
	int a=printi(10);
}