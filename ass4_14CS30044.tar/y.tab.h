/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    auto_KEYWORD = 258,
    enum_KEYWORD = 259,
    restrict_KEYWORD = 260,
    unsigned_KEYWORD = 261,
    break_KEYWORD = 262,
    extern_KEYWORD = 263,
    return_KEYWORD = 264,
    void_KEYWORD = 265,
    case_KEYWORD = 266,
    float_KEYWORD = 267,
    short_KEYWORD = 268,
    volatile_KEYWORD = 269,
    char_KEYWORD = 270,
    for_KEYWORD = 271,
    signed_KEYWORD = 272,
    while_KEYWORD = 273,
    const_KEYWORD = 274,
    goto_KEYWORD = 275,
    sizeof_KEYWORD = 276,
    _Bool_KEYWORD = 277,
    continue_KEYWORD = 278,
    if_KEYWORD = 279,
    static_KEYWORD = 280,
    _Complex_KEYWORD = 281,
    default_KEYWORD = 282,
    inline_KEYWORD = 283,
    struct_KEYWORD = 284,
    do_KEYWORD = 285,
    int_KEYWORD = 286,
    switch_KEYWORD = 287,
    double_KEYWORD = 288,
    long_KEYWORD = 289,
    typedef_KEYWORD = 290,
    else_KEYWORD = 291,
    register_KEYWORD = 292,
    union_KEYWORD = 293,
    _Imaginary_KEYWORD = 294,
    IDENTIFIER = 295,
    INTEGER_CONST = 296,
    FLOATING_CONST = 297,
    ENUMERATION_CONST = 298,
    CHARACTER_CONST = 299,
    STRING_LITERAL = 300,
    LEFT_SQUARE_BRACKET = 301,
    RIGHT_SQUARE_BRACKET = 302,
    LEFT_ROUND_BRACKET = 303,
    RIGHT_ROUND_BRACKET = 304,
    LEFT_CURLY_BRACKET = 305,
    RIGHT_CURLY_BRACKET = 306,
    DOT = 307,
    ARROW = 308,
    INCREMENT = 309,
    DECREMENT = 310,
    AND = 311,
    ASTERISK = 312,
    PLUS = 313,
    MINUS = 314,
    TILDA = 315,
    NOT = 316,
    FORWARD_SLASH = 317,
    PERCENT = 318,
    LEFT_SHIFT = 319,
    RIGHT_SHIFT = 320,
    LESS_THAN = 321,
    GREATER_THAN = 322,
    LESS_THAN_EQUAL_T0 = 323,
    GREATER_THAN_EQUAL_TO = 324,
    EQUAL_TO = 325,
    NOT_EQUAL_TO = 326,
    XOR = 327,
    OR = 328,
    LOGICAL_AND = 329,
    LOGICAL_OR = 330,
    QUESTION_MARK = 331,
    COLON = 332,
    SEMI_COLON = 333,
    ELLIPSIS = 334,
    ASSIGNED = 335,
    ASTERISK_EQUAL_TO = 336,
    SLASH_EQUAL_TO = 337,
    PERCENT_EQUAL_TO = 338,
    PLUS_EQUAL_TO = 339,
    MINUS_EQUAL_TO = 340,
    LEFT_SHIFT_EQUAL_TO = 341,
    RIGHT_SHIFT_EQUAL_TO = 342,
    AND_EQUAL_TO = 343,
    XOR_EQUAL_TO = 344,
    OR_EQUAL_TO = 345,
    COMMA = 346,
    HASH = 347,
    SINGLE_LINE_COMMENT = 348,
    MULTI_LINE_COMMENT = 349
  };
#endif
/* Tokens.  */
#define auto_KEYWORD 258
#define enum_KEYWORD 259
#define restrict_KEYWORD 260
#define unsigned_KEYWORD 261
#define break_KEYWORD 262
#define extern_KEYWORD 263
#define return_KEYWORD 264
#define void_KEYWORD 265
#define case_KEYWORD 266
#define float_KEYWORD 267
#define short_KEYWORD 268
#define volatile_KEYWORD 269
#define char_KEYWORD 270
#define for_KEYWORD 271
#define signed_KEYWORD 272
#define while_KEYWORD 273
#define const_KEYWORD 274
#define goto_KEYWORD 275
#define sizeof_KEYWORD 276
#define _Bool_KEYWORD 277
#define continue_KEYWORD 278
#define if_KEYWORD 279
#define static_KEYWORD 280
#define _Complex_KEYWORD 281
#define default_KEYWORD 282
#define inline_KEYWORD 283
#define struct_KEYWORD 284
#define do_KEYWORD 285
#define int_KEYWORD 286
#define switch_KEYWORD 287
#define double_KEYWORD 288
#define long_KEYWORD 289
#define typedef_KEYWORD 290
#define else_KEYWORD 291
#define register_KEYWORD 292
#define union_KEYWORD 293
#define _Imaginary_KEYWORD 294
#define IDENTIFIER 295
#define INTEGER_CONST 296
#define FLOATING_CONST 297
#define ENUMERATION_CONST 298
#define CHARACTER_CONST 299
#define STRING_LITERAL 300
#define LEFT_SQUARE_BRACKET 301
#define RIGHT_SQUARE_BRACKET 302
#define LEFT_ROUND_BRACKET 303
#define RIGHT_ROUND_BRACKET 304
#define LEFT_CURLY_BRACKET 305
#define RIGHT_CURLY_BRACKET 306
#define DOT 307
#define ARROW 308
#define INCREMENT 309
#define DECREMENT 310
#define AND 311
#define ASTERISK 312
#define PLUS 313
#define MINUS 314
#define TILDA 315
#define NOT 316
#define FORWARD_SLASH 317
#define PERCENT 318
#define LEFT_SHIFT 319
#define RIGHT_SHIFT 320
#define LESS_THAN 321
#define GREATER_THAN 322
#define LESS_THAN_EQUAL_T0 323
#define GREATER_THAN_EQUAL_TO 324
#define EQUAL_TO 325
#define NOT_EQUAL_TO 326
#define XOR 327
#define OR 328
#define LOGICAL_AND 329
#define LOGICAL_OR 330
#define QUESTION_MARK 331
#define COLON 332
#define SEMI_COLON 333
#define ELLIPSIS 334
#define ASSIGNED 335
#define ASTERISK_EQUAL_TO 336
#define SLASH_EQUAL_TO 337
#define PERCENT_EQUAL_TO 338
#define PLUS_EQUAL_TO 339
#define MINUS_EQUAL_TO 340
#define LEFT_SHIFT_EQUAL_TO 341
#define RIGHT_SHIFT_EQUAL_TO 342
#define AND_EQUAL_TO 343
#define XOR_EQUAL_TO 344
#define OR_EQUAL_TO 345
#define COMMA 346
#define HASH 347
#define SINGLE_LINE_COMMENT 348
#define MULTI_LINE_COMMENT 349

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 11 "ass4_14CS30044.y" /* yacc.c:1909  */

  int intVal;
  float floatVal;
  char *charVal;

#line 248 "y.tab.h" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
