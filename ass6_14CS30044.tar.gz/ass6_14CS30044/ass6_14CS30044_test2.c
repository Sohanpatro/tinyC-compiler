int printi(int num);
int prints(char * c);
int readi(int *eP);

int main()
{
	prints("Basic IO opearations and Computations:\n");
  int x, y, z;
  int *ep;
  prints("Enter 2 nos.:\n");
  x = readi(&ep);
  y=readi(&ep);
//  z = x+y;
  prints("Sum = ");
  printi(x+y);
  prints("\n");
  
   return 0;
}

/*
int main()
{
    prints("Lest find the max and 2nd max of an array of integers\n");
    prints("Enter the number n:\n");
    int n,*ep,largest=-100,secondlargest=-100;
    n=readi(&ep);
    prints("Now enter ");
    printi(n);
    prints(" integers (one in each line)\n");
    int i;
    for(i=0;i<n;i++)
    {
        x=readi(&ep);
        printi(x);
        prints("\n");
        if(x>=largest)
        {
            secondlargest=largest;
            largest=x;
        }
        else if(x>=secondlargest)
        {
            secondlargest=x;
        }
    }
    prints("The largest number entered is ");
    printi(largest);
    prints("\nThe second largest number entered is");
    printi(secondlargest);
    prints("\nEnd of Program!!!\n");
}*/
