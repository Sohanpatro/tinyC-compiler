

int printi(int num);
int prints(char * c);
int readi(int *eP);

int main()
{
   int a[10], arr, *ep;
   prints("Testing Basic arithmetic operations using ARRAY:");
   prints("\nEnter 2 numbers:\n");
    arr = readi(&ep);
    a[0] = readi(&ep);
    a[1] = a[0]+arr;
    //arel=a[0]+a[1];
    prints("Sum = ");
    printi(a[1]);
    prints("\n");
    int x, y;
    x=2;
    y=3;
    
    
}
